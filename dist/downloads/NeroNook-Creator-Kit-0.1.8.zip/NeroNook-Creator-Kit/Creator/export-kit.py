#!/usr/bin/env python3
"""Export a frozen SDK/tools snapshot, without host code or user data."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import tempfile
import zipfile

from integrity import source_files, verify

SDK = Path(__file__).resolve().parents[1]


def export(sdk, output):
    metadata = json.loads((sdk/'Creator/kit.json').read_text())
    if output.suffix != '.zip' or output.is_symlink():
        raise ValueError('Choose a regular .zip destination.')
    frozen = {}
    for directory in ['Creator', 'NookPluginSDK']:
        for name, path in source_files(sdk/directory).items():
            frozen[directory+'/'+name] = path.read_bytes()
    for path in sorted(sdk.glob('*.md')) + [sdk/'module.py', sdk/'LICENSE']:
        if path.is_symlink() or not path.is_file():
            raise ValueError('SDK references must be normal files.')
        frozen[path.name] = path.read_bytes()
    hashes = {name: hashlib.sha256(data).hexdigest() for name, data in frozen.items()}
    snapshot = dict(version=metadata['version'], hostBaseline=metadata['starterMinimumHost'],
                    sourceHostVersion=metadata['sourceHostVersion'], apiVersion=metadata['apiVersion'],
                    distribution=metadata['distribution'], license=metadata['license'], files=hashes)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.nook-kit-', dir=output.parent) as folder:
        staged = Path(folder)/'kit.zip'
        with zipfile.ZipFile(staged, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
            for name, data in sorted(frozen.items()):
                archive.writestr('NeroNook-Creator-Kit/'+name, data)
            archive.writestr('NeroNook-Creator-Kit/KIT-SNAPSHOT.json', json.dumps(snapshot, indent=2)+'\n')
        with zipfile.ZipFile(staged) as archive:
            archive.extractall(Path(folder)/'extracted')
        verify(Path(folder)/'extracted/NeroNook-Creator-Kit',
               Path(folder)/'extracted/NeroNook-Creator-Kit/KIT-SNAPSHOT.json', allow_snapshot=True)
        if output.exists():
            previous = output.with_name(output.stem+'-previous-'+hashlib.sha256(output.read_bytes()).hexdigest()[:12]+'.zip')
            if previous.exists():
                if previous.read_bytes() != output.read_bytes():
                    raise ValueError('Previous artifact destination differs; no archive was replaced.')
            else:
                output.rename(previous)
        os.replace(staged, output)
    return snapshot


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    version = json.loads((SDK/'Creator/kit.json').read_text())['version']
    parser.add_argument('output', type=Path, nargs='?', default=SDK.parent/'build'/('NeroNook-Creator-Kit-'+version+'.zip'))
    args = parser.parse_args()
    snapshot = export(SDK, args.output.absolute())
    print('Verified local creator kit '+snapshot['version']+': '+str(args.output.absolute()))


if __name__ == '__main__':
    main()
