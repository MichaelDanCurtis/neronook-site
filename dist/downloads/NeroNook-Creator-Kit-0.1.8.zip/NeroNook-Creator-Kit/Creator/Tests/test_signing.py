import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import signing


class SigningTests(unittest.TestCase):
    def test_no_silent_temporary_identity(self):
        with patch.dict(os.environ, {}, clear=True), patch.object(signing, 'installed_reference', return_value=None):
            for identity in (None, '-', ''):
                with self.assertRaises(signing.SigningError): signing.resolve('com.example.fixture', identity)

    def test_reuses_installed_identity(self):
        with tempfile.TemporaryDirectory() as root:
            app = Path(root)
            with patch.dict(os.environ, {}, clear=True), patch.object(signing, 'installed_reference', return_value=app), patch.object(signing, 'details', return_value={'Identifier':'com.example.fixture','Authority':'Stable Certificate'}):
                self.assertEqual(signing.resolve('com.example.fixture'), ('Stable Certificate', app))

    def test_update_must_satisfy_prior_requirement(self):
        with tempfile.TemporaryDirectory() as root:
            reference=Path(root)
            with patch.object(signing, 'details', return_value={'Identifier':'com.example.fixture','requirement':'identifier "com.example.fixture" and anchor apple generic'}), patch.object(signing, 'command') as call:
                signing.verify_update('candidate', reference)
                self.assertEqual(call.call_args.args[0][-2:], ['=identifier "com.example.fixture" and anchor apple generic', 'candidate'])

    def test_timeout_never_retries_or_falls_back(self):
        with patch.object(subprocess, 'run', side_effect=subprocess.TimeoutExpired('codesign',25)) as run:
            with self.assertRaises(signing.SigningError): signing.sign('candidate', 'Certificate')
            self.assertEqual(run.call_count,1)

    def test_public_distribution_rejects_development_or_incomplete_signatures(self):
        valid=dict(Authority='Developer ID Application: Fixture',hardenedRuntime=True,secureTimestamp=True)
        for fields in [dict(valid,Authority='Apple Development: Fixture'),dict(valid,hardenedRuntime=False),dict(valid,secureTimestamp=False)]:
            with patch.object(signing,'details',return_value=fields):
                with self.assertRaises(signing.SigningError):signing.verify_distribution('candidate')
        with patch.object(signing,'details',return_value=valid):
            self.assertEqual(signing.verify_distribution('candidate'),valid)

if __name__ == '__main__': unittest.main()
