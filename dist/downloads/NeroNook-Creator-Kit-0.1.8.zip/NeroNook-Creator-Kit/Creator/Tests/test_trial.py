import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parents[1]))
import nook
import trial


class TrialTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.project = Path(self.temp.name)/'Private person project'
        self.project.mkdir()
        self.output = self.project/'build/trial.json'

    def collect(self, **kwargs):
        with patch.object(trial, 'local_environment', return_value=dict(osVersion='14.8', architecture='arm64')):
            with patch.object(nook, 'doctor'), patch.object(trial, 'local_dependency_only'), patch.object(nook, 'run'):
                return trial.collect(self.project, self.output, **kwargs)

    def test_automated_success_never_infers_human_acceptance(self):
        value = self.collect(role='agent')
        self.assertTrue(value['automatedPassed'])
        self.assertTrue(all(x['status']=='not-run' for x in value['humanChecks'].values()))
        self.assertNotIn(str(self.project), self.output.read_text())
        self.assertFalse(value['uploads'])
        self.assertFalse(value['installedByCollector'])

    def test_human_failure_and_skips_survive_automated_success(self):
        value = self.collect(role='owner', observations=dict(install='pass', customView='fail', multipleDisplays='skipped'))
        self.assertEqual(value['humanChecks']['customView']['status'], 'fail')
        self.assertEqual(value['humanChecks']['multipleDisplays']['status'], 'skipped')
        self.assertEqual(value['humanChecks']['restore']['status'], 'not-run')

    def test_failure_saves_stage_without_sensitive_exception(self):
        with patch.object(trial, 'local_environment', return_value={}), patch.object(nook, 'doctor', side_effect=nook.Problem('PRIVATE_ENV_VALUE')):
            with self.assertRaises(nook.Problem):trial.collect(self.project, self.output)
        value=json.loads(self.output.read_text())
        self.assertFalse(value['automatedPassed'])
        self.assertEqual(value['automatedChecks'],[dict(name='preflight',status='fail')])
        self.assertNotIn('PRIVATE_ENV_VALUE',self.output.read_text())

    def test_source_or_existing_receipt_is_not_overwritten(self):
        for output in [self.project/'Package.swift', self.project/'build/../Sources/report.json']:
            with self.assertRaises(nook.Problem):trial.collect(self.project,output)
        self.output.parent.mkdir();self.output.write_text('historical')
        with self.assertRaises(nook.Problem):trial.collect(self.project,self.output)
        self.assertEqual(self.output.read_text(),'historical')

    def test_invalid_observation_is_rejected_before_execution(self):
        with patch.object(nook,'doctor',side_effect=AssertionError('executed')):
            with self.assertRaises(nook.Problem):trial.collect(self.project,self.output,observations=dict(restore='probably'))
            with self.assertRaises(nook.Problem):trial.collect(self.project,self.output,observations=dict(unknown='pass'))

    def test_host_checkout_dependency_is_rejected(self):
        for dependencies in [[],[dict(path='/host/SDK',dependencies=[])],[dict(path=str(self.project/'Vendor/NookPluginSDK'),dependencies=[{}])]]:
            with patch.object(nook,'run',return_value=json.dumps(dict(dependencies=dependencies)).encode()):
                with self.assertRaises(nook.Problem):trial.local_dependency_only(self.project)

    def test_only_vendored_leaf_dependency_is_accepted(self):
        value=dict(dependencies=[dict(path=str(self.project/'Vendor/NookPluginSDK'),dependencies=[])])
        with patch.object(nook,'run',return_value=json.dumps(value).encode()):trial.local_dependency_only(self.project)
