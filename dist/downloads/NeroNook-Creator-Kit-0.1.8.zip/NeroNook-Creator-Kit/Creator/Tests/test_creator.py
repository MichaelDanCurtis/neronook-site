import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

spec=importlib.util.spec_from_file_location('creator',Path(__file__).parents[1]/'nook.py')
creator=importlib.util.module_from_spec(spec);spec.loader.exec_module(creator)

class CreatorTests(unittest.TestCase):
    def testIndependentCopyEscapesDisplayNameAndRecordsSDK(self):
        with tempfile.TemporaryDirectory() as folder:
            destination=Path(folder)/'My Module'
            creator.create(destination,'example.test.module','A "quoted" module 🌦')
            self.assertEqual(json.loads((destination/'Resources/NookPlugin.json').read_text())['name'],'A "quoted" module 🌦')
            self.assertEqual(json.loads((destination/'Resources/NookPlugin.json').read_text())['icon']['symbol'],'square.stack.3d.up.fill')
            lock=json.loads((destination/'SDK-SNAPSHOT.json').read_text())
            self.assertIn('Sources/NookPluginSDK/PluginProtocol.swift',lock['files'])
            self.assertTrue((destination/'Tools/nook.py').is_file())
            self.assertTrue((destination/'Resources/Views/studio/index.html').is_file())
            self.assertIn('Sources/NookPluginSDK/PluginWebSurface.swift',lock['files'])
            self.assertEqual(lock['hostBaseline'],'0.20.1')
            self.assertEqual(lock['sourceHostVersion'],'0.28.1')
            self.assertEqual(lock['creatorVersion'],'0.1.8')
            self.assertEqual((destination/'LICENSE').read_bytes(), (destination/'Vendor/NookPluginSDK/LICENSE').read_bytes())
            self.assertFalse(any(p.is_symlink() for p in destination.rglob('*')))
            # The generated tool can itself create a project without the host checkout.
            with patch.object(creator,'HERE',destination/'Tools'):
                creator.create(Path(folder)/'Second','example.second','Second')
            self.assertTrue((Path(folder)/'Second/Vendor/NookPluginSDK/Package.swift').is_file())
    def testNeverOverwritesExistingOrSymlinkDestination(self):
        with tempfile.TemporaryDirectory() as folder:
            target=Path(folder)/'existing';target.mkdir();(target/'keep').write_text('saved')
            with self.assertRaises(creator.Problem):creator.create(target,'example.test','Test')
            self.assertEqual((target/'keep').read_text(),'saved')
            link=Path(folder)/'link';link.symlink_to(Path(folder)/'missing')
            with self.assertRaises(creator.Problem):creator.create(link,'example.test','Test')
            self.assertTrue(link.is_symlink())
    def testRejectsInvalidIdentityBeforeCreatingFiles(self):
        with tempfile.TemporaryDirectory() as folder:
            target=Path(folder)/'new'
            for identity in ['../../escape','example;open','Example.Bad','one']:
                with self.assertRaises(creator.Problem):creator.create(target,identity,'Demo')
            self.assertFalse(target.exists())
if __name__=='__main__':unittest.main()
