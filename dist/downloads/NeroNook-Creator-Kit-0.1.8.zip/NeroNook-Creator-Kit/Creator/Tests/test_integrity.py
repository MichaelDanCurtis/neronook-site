import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parents[1]))
import integrity
import nook


class IntegrityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)/'SDK'
        self.root.mkdir()
        (self.root/'Sources').mkdir()
        (self.root/'Sources/Module.swift').write_text('public let value = 1\n')
        self.lock = Path(self.temp.name)/'SDK-SNAPSHOT.json'
        self.lock.write_text(json.dumps(dict(files=integrity.fingerprints(self.root))))

    def test_changed_source_is_rejected_without_rewriting_snapshot(self):
        before = self.lock.read_bytes()
        (self.root/'Sources/Module.swift').write_text('changed implementation')
        with self.assertRaisesRegex(integrity.IntegrityError, 'changed'):
            integrity.verify(self.root, self.lock)
        self.assertEqual(self.lock.read_bytes(), before)

    def test_missing_source_is_rejected(self):
        (self.root/'Sources/Module.swift').unlink()
        with self.assertRaises(integrity.IntegrityError): integrity.verify(self.root, self.lock)

    def test_extra_source_is_rejected_but_caches_are_ignored(self):
        (self.root/'.build').mkdir(); (self.root/'.build/cache').write_text('cache')
        self.assertEqual(integrity.verify(self.root, self.lock), 1)
        (self.root/'Sources/New.swift').write_text('new')
        with self.assertRaisesRegex(integrity.IntegrityError, 'extra'):
            integrity.verify(self.root, self.lock)

    def test_path_escape_never_reads_the_outside_file(self):
        outside = Path(self.temp.name)/'private.txt'; outside.write_text('DO NOT READ')
        for name in ['../private.txt', str(outside), 'Sources/../../private.txt', 'Sources\\private.txt', './private.txt']:
            self.lock.write_text(json.dumps(dict(files={name:'0'*64})))
            with patch.object(Path, 'read_bytes', side_effect=AssertionError('file data read')):
                with self.assertRaises(integrity.IntegrityError): integrity.verify(self.root, self.lock)

    def test_linked_source_or_directory_never_reads_its_target(self):
        source = self.root/'Sources/Module.swift'; source.unlink()
        outside = Path(self.temp.name)/'outside'; outside.mkdir(); (outside/'Module.swift').write_text('outside')
        source.symlink_to(outside/'Module.swift')
        with self.assertRaises(integrity.IntegrityError): integrity.verify(self.root, self.lock)
        source.unlink(); (self.root/'Sources').rmdir(); (self.root/'Sources').symlink_to(outside)
        with self.assertRaises(integrity.IntegrityError): integrity.verify(self.root, self.lock)

    def test_duplicate_snapshot_fields_are_rejected(self):
        self.lock.write_text('{"files":{"Sources/Module.swift":"'+'0'*64+'"},"files":{}}')
        with self.assertRaisesRegex(integrity.IntegrityError, 'duplicate'): integrity.verify(self.root, self.lock)

    def test_large_file_and_total_limits_are_enforced(self):
        with patch.object(integrity, 'MAX_FILE', 1):
            with self.assertRaises(integrity.IntegrityError): integrity.fingerprints(self.root)
        with patch.object(integrity, 'MAX_TOTAL', 1):
            with self.assertRaises(integrity.IntegrityError): integrity.fingerprints(self.root)

    def test_linked_snapshot_is_rejected(self):
        link = Path(self.temp.name)/'linked.json'; link.symlink_to(self.lock)
        with self.assertRaises(integrity.IntegrityError): integrity.verify(self.root, link)

    def test_report_cannot_overwrite_project_source(self):
        before = (self.root/'Sources/Module.swift').read_bytes()
        with self.assertRaises(nook.Problem): nook.doctor(self.root, self.root/'Sources/Module.swift')
        self.assertEqual((self.root/'Sources/Module.swift').read_bytes(), before)

    def test_report_parent_traversal_cannot_overwrite_source(self):
        source = self.root/'Sources/Module.swift'; before = source.read_bytes()
        with self.assertRaises(nook.Problem):
            nook.doctor(self.root, self.root/'build/../Sources/Module.swift')
        self.assertEqual(source.read_bytes(), before)

    def test_report_parent_alias_cannot_overwrite_source(self):
        source = self.root/'Sources/Module.swift'; before = source.read_bytes()
        alias = Path(self.temp.name)/'source-alias'; alias.symlink_to(self.root/'Sources')
        with self.assertRaises(nook.Problem):
            nook.doctor(self.root, alias/'Module.swift')
        self.assertEqual(source.read_bytes(), before)

    def test_failed_preflight_writes_safe_actionable_report(self):
        project = Path(self.temp.name)/'Module'
        nook.create(project, 'example.preflight', 'Preflight')
        source = project/'Vendor/NookPluginSDK/Sources/NookPluginSDK/PluginProtocol.swift'
        source.write_text('SECRET_PAYLOAD_DO_NOT_REPORT')
        report = project/'build/preflight.json'
        with self.assertRaises(nook.Problem): nook.doctor(project, report)
        value = json.loads(report.read_text())
        self.assertFalse(value['success'])
        self.assertEqual(value['checks'][0]['status'], 'fail')
        self.assertNotIn('SECRET_PAYLOAD_DO_NOT_REPORT', report.read_text())
        self.assertNotIn(str(project), report.read_text())
        self.assertEqual(value['license'], 'MIT')

    def test_preflight_handles_nonobject_manifest_without_trace_or_payload(self):
        project = Path(self.temp.name)/'Broken Module'
        nook.create(project, 'example.broken', 'Broken')
        (project/'Resources/NookPlugin.json').write_text('["PRIVATE_BAD_MANIFEST"]')
        report = project/'build/preflight.json'
        with self.assertRaises(nook.Problem): nook.doctor(project, report)
        self.assertFalse(json.loads(report.read_text())['success'])
        self.assertNotIn('PRIVATE_BAD_MANIFEST', report.read_text())

    def test_preflight_identifies_missing_xctest_before_a_build(self):
        project = Path(self.temp.name)/'No XCTest'
        nook.create(project, 'example.no-tests', 'No XCTest')
        report = project/'build/preflight.json'
        original = nook.run
        def without_xctest(args, *a, **kw):
            if args == ['xcrun','--find','xctest']:raise nook.Problem('tool unavailable')
            return original(args,*a,**kw)
        with patch.object(nook,'run',side_effect=without_xctest):
            with self.assertRaises(nook.Problem):nook.doctor(project,report)
        checks=json.loads(report.read_text())['checks']
        check=next(x for x in checks if x['name']=='Native test tools')
        self.assertEqual(check['status'],'fail')
        self.assertIn('full Xcode',check['detail'])


class ExportTests(unittest.TestCase):
    def test_export_excludes_host_and_preserves_previous_artifact_on_failure(self):
        spec = importlib.util.spec_from_file_location('export_kit', Path(__file__).parents[1]/'export-kit.py')
        module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)/'SDK'; (root/'Creator').mkdir(parents=True); (root/'NookPluginSDK').mkdir()
            (root/'Creator/kit.json').write_text(json.dumps(dict(version='test', starterMinimumHost='0.20.1', sourceHostVersion='0.28.1', apiVersion=1, distribution='local-preview', license='MIT')))
            (root/'NookPluginSDK/Package.swift').write_text('SDK')
            (root/'module.py').write_text('module'); (root/'README.md').write_text('reference')
            (root/'LICENSE').write_text('MIT test notice')
            (root/'Host').mkdir(); (root/'Host/private.txt').write_text('NOT INCLUDED')
            output = Path(folder)/'kit.zip'; snapshot = module.export(root, output)
            self.assertFalse(any('Host/' in x for x in snapshot['files']))
            self.assertIn('LICENSE', snapshot['files'])
            previous = output.read_bytes()
            (root/'NookPluginSDK/leak.swift').symlink_to(root/'Host/private.txt')
            with self.assertRaises(integrity.IntegrityError): module.export(root, output)
            self.assertEqual(output.read_bytes(), previous)


if __name__ == '__main__': unittest.main()
