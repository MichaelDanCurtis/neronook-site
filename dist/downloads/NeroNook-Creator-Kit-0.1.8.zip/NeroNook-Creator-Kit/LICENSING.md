# SDK licensing

The independently authored source and documentation under `SDK/` are licensed under the [MIT License](LICENSE), including the Swift SDK, creator tools, templates and examples. The copied Swift package also carries its own `LICENSE`, and generated projects retain the notice so the standalone copies remain usable without this repository.

Creators may use the SDK in free or commercial plugins under their own product license. Keep the MIT copyright/permission notice with copies or substantial portions of the SDK and starter code. The license does not grant NeroNook branding or endorsement, account entitlement, permission to redistribute a provider's models/assets, or rights in third-party integrations.

This scope does not license the NeroNook host, independent plugins, bundled third-party software or external services. Their terms remain separate. The host's existing `ThirdPartyLicenses` notices stay with its binary distribution. This SDK currently has no third-party Swift package dependencies; Apple system frameworks and the Swift/Python toolchains are prerequisites, not copied into the kit.

The creator kit remains a versioned preview until its compatibility and clean-environment checks pass. An MIT license is not a security review, notarization or a promise of permanent protocol stability. See [compatibility](COMPATIBILITY.md) and [signing](SIGNING.md).
