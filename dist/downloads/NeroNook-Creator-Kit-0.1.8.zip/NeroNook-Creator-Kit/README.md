# NeroNook SDK and creator kit

Build independent modules without the NeroNook app or source checkout. NeroNook 0.20 supplies a 16:9 module surface, a separate status line, per-display selection, settings access, reviewed controls and shared action routing. Plugins own their integrations, permissions, credentials and domain behavior.

## Start a native module

The local creator kit 0.1.8 includes a standalone SwiftUI starter, verified vendored SDK, read-only preflight reports, manifest/message validation, native preview, replay fixtures, protocol checks and signed local packaging. Hosted mode has its own window lifecycle and does not create a hidden preview window.

```sh
python3 Creator/nook.py create /path/to/MyModule --id com.example.my-module --name "My Module"
cd /path/to/MyModule
python3 Tools/nook.py doctor . --report build/preflight.json
python3 Tools/nook.py test .
python3 Tools/nook.py dev .
python3 Tools/nook.py pack .
```

Install the resulting app using NeroNook Settings → Modules. No host rebuild is needed. Requires macOS 14+, full Xcode with Swift 6 and XCTest, and Python 3 for the tools; the module app itself has no Python dependency. See [creator instructions](Creator/README.md).

## Reference

- [Native package, lifecycle and display protocol](NATIVE-PLUGINS.md)
- [Shared actions, permissions, results and events](ACTIONS.md)
- [Keyboard channel observations and source following](HOST-SWITCH-EVENTS.md)
- [Module presentation](MODULE-PRESENTATION.md)
- [Compatibility and migration](COMPATIBILITY.md)
- [Independent creator trial and local results](CREATOR-TRIAL.md)
- [Local lightweight JavaScript format and historical guide](LEGACY-MODULES.md)

The Swift SDK is in `NookPluginSDK/`. Generated projects vendor an exact copy with file hashes, rather than linking back to the host repository. Legacy stdio remains supported; the optional application-launch channel is available for independently provisioned applications such as Catalyst plugins, using their own platform-specific build.

This is a **local developer preview**, not a public stable SDK release. The SDK/tools/examples are [MIT-licensed](LICENSING.md). Publisher trust, distribution signing/notarization, third-party clean-install acceptance and automated upgrade/rollback remain release gates. The kit export contains source and docs only, with no host binary, accounts, credentials or installed plugins.

Editable text, number, slider, toggle and choice inputs use [forms-v1](FORMS.md), backed by the shared action service and in-card review.

Calendar, inbox, task-list and file-browser surfaces use [collections-v1](COLLECTIONS.md). The shared native renderer also works in independently built plugin windows.

Plugins may also supply [fully custom Nook views and native windows](CUSTOM-VIEWS.md), with a working example in new creator projects.

## Volume endpoints

Independent plugins can advertise optional volume controls through [`volume-v1`](VOLUME.md). The owner binds a target to a specific Mac audio output; media keys and the Nero HUD use fresh, bounded, confirmed commands. Vendor transport remains in the plugin.
