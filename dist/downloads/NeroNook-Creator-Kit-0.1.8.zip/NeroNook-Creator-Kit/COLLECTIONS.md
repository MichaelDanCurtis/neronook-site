# Native collections · collections-v1

An optional, provider-neutral panel presentation for calendars, inboxes, task lists and file browsers. Negotiate `collections-v1` in hello and ready before publishing `PluginPanel.collection`. Older hosts receive the provider's previous cards or sections. The host has no provider identifiers, networking, account logic or special commands for these layouts.

`PluginCollection` supplies the layout, title, status/empty text, items and up to four toolbar actions. An item has a stable ID, title, subtitle, detail, category, optional symbol/date, unread/completed state and an optional action. The native inbox provides search, unread filtering, sender/subject/date rows and a selected-message summary. Tasks provide due-date filters and status rows. Files provide list/grid and name/recent ordering. Calendar supplies 28–42 days in full weeks, a selected date and selected-day agenda items. Providers own date selection/loading and must not present unloaded days as known empty.

The shared `PluginCollectionView` renderer is available to both the host and standalone plugin windows. Plugins can vendor the SDK and build independently. Renderer state such as search, selection and file view mode remains local to the view. Calendar date state belongs to the provider. It does not run plugin code in the host.

Actions retain the existing opaque `action` message, enabled-state validation and confirmation semantics. Only actions in the current snapshot can run. Rendered completion circles describe data; they do not imply a write capability. Providers choose whether to offer an edit/completion action through their own existing authorization model. No new OAuth or cross-plugin access is granted by this presentation feature.

Bounds: 96 items per collection, 192 across a snapshot; unique item/day IDs; titles 160 characters, subtitle 200, detail 500, category/symbol 80. Dates must be finite. Collections cannot share a panel with forms, cards, diagrams or media. Conflicting definitions of the same action ID are rejected. Existing 128 KiB message framing remains in force. Keep long or unsupported remote content out of snapshots.
