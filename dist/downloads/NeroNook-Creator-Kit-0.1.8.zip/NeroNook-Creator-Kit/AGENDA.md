# Agenda contributions · agenda-v1

An independent calendar module can negotiate agenda-v1 in ready. The host sends agendaRequest with agendaDate (SDK Date encoding); the provider returns agenda messages with PluginAgenda. Both messages use the existing identity/session/sequence envelope.

The provider supplies the requested local calendar day and today. Each response includes fetchedAt, expiresAt and at most 64 uniquely identified entries. Source-data lifetime is at most ten minutes; re-emitting a response does not extend the original data freshness. The host ignores unsolicited days and clears expired, disabled or disconnected contributions. Links must be HTTPS without embedded credentials. Metadata never contains authentication tokens.

Calendar providers are trusted native code and must report source timestamps honestly. A host heartbeat does not prove provider data is fresh. Generic host merge logic deduplicates matching external UID plus occurrence start while preserving recurring occurrences. Integration-specific parsing, account selection and networking stay in the plugin.
