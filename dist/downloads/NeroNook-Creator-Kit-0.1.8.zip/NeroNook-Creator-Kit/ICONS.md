# Module icons

Starting with NeroNook 0.20.1, a plugin can declare its identity in `Resources/NookPlugin.json`:

```json
"icon": {
  "symbol": "cloud.sun.fill",
  "color": "FFD172"
}
```

Use a recognizable SF Symbol for the module's purpose and a light accent color. The host draws a consistent rounded tile in the selector, header and installation review. Names remain visible and accessible; color is never the sole identifier. Icons are static package metadata and remain available when the plugin is stopped or disconnected. They do not indicate current status, authentication or trust.

An optional `"badge": "lock.fill"` adds a small secondary symbol. Reserve it for a useful distinction between otherwise similar modules. Both symbol strings are bounded to 80 lowercase letters, digits and dots; color is exactly six RGB hex digits without `#`. A symbol unavailable on an older Mac uses a neutral fallback; an unavailable badge is omitted. Keep the main shape legible at 32 points. Check dark and light surfaces and Retina scaling.

The SDK includes `PluginIcon` validation and, on macOS, a reusable SwiftUI view for plugin-owned windows:

```swift
PluginIconView(PluginIcon(symbol: "cloud.sun.fill", color: "FFD172"), size: 40)
```

The creator template includes an editable icon declaration automatically. Packaging copies the manifest and signs it with the app. Icon changes require repackaging and the normal plugin update; never edit an installed signed bundle. Existing plugins may add this JSON metadata without upgrading their runtime SDK, because older manifest decoders ignore unknown keys. New source code using `PluginIconView` requires an explicit SDK snapshot update.

## Custom artwork

For original PNG artwork, omit `manifest.icon` and provide `PluginSnapshot.iconPNG` using `artwork-v1`. Existing artwork support is preserved: PNG only, at most 8 KiB per image, dimensions 1–256 pixels, at most 80 KiB of combined snapshot artwork. The host validates decoding. Use transparency and generous internal margins; the host fits artwork to 32 points in the selector and 34 in the header. Snapshot artwork is available only while supplied by the plugin. No remote images are loaded.

Precedence: explicit manifest icon, otherwise valid snapshot PNG, otherwise the host's neutral symbol. This lets a plugin deliberately replace its older snapshot artwork with a static identity. Artwork is plugin-owned; the host contains no vendor identity map or branded assets. These functional symbols are not official vendor logos. Use only artwork you have permission to distribute.
