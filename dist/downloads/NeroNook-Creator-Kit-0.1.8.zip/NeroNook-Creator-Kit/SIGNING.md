# Signing independent native modules

Installable creator builds need a stable certificate identity. On first packaging, supply `--identity` or `NERONOOK_SIGNING_IDENTITY`. For an update, the tools can reuse the installed module's public signing identity. They require the same bundle identifier and verify the candidate against the installed app's designated requirement. No private key or credential is copied into a module or this kit.

`pack` and `dev` stage a fresh, content-addressed app; they do not replace the running or installed module. Signing has a 25-second bound and one failure, without retries or ad hoc fallback. The `test` command uses a separate `.protocol-test` identity solely for isolated process checks; that package is not an installable update.

Stable signing avoids an unnecessary identity change between builds. It does not guarantee that macOS will never ask for Keychain access. If a prompt returns, identify the requesting app, item name and whether it occurs during packaging or normal use. Approve only the intended app/item in the system UI. Do not put account passwords in scripts, export private keys or widen a credential's access to all applications.

An Apple Development signature used for local testing does not establish a public release. Developer ID distribution, notarization, publisher trust, independent plugin licensing and clean-Mac acceptance remain separate gates. The SDK/tools/examples have their own MIT notice. See [compatibility and recovery](COMPATIBILITY.md).

## Public native module candidate

Use `python3 Tools/nook.py pack . --developer-id --identity YOUR_DEVELOPER_ID` for a first distribution build. This requires Developer ID Application, hardened runtime and a secure timestamp; the package retains the SDK notice. The toolkit never uploads automatically. The starter needs no runtime exception entitlements; integrations must review their own requirements.

Submit that exact ZIP with `xcrun notarytool submit MODULE.zip --keychain-profile YOUR_PROFILE --no-wait --output-format json`. Save the returned submission ID and archive digest. Check the existing ID with `notarytool info`; an upload timeout is an unknown outcome to reconcile, not permission to upload again. Keep credentials in your own Keychain profile, never in source or reports.

Only after Apple returns Accepted, run `xcrun stapler staple MODULE.app`, `xcrun stapler validate MODULE.app` and `spctl --assess --type execute --verbose=4 MODULE.app`. Then create the delivery ZIP again so it contains the stapled ticket. Keep the original submission archive, status and final digest. A successful notarization is not publisher endorsement, hardware/account acceptance or permission to publish somebody else's assets.

See Apple's [notarization requirements](https://developer.apple.com/documentation/security/notarizing-macos-software-before-distribution) and [custom workflow](https://developer.apple.com/documentation/security/customizing-the-notarization-workflow). A host distribution and each independently shipped native module need their own release verification; the host's ticket does not notarize plugins installed later.
