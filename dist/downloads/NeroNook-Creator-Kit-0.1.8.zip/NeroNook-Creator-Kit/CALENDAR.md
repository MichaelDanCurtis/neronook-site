# Optional read-only calendar adapter

`PluginCalendarContract` is a portable convention on the existing **actions-v1**
transport, not a new wire feature or a dependency between products. Providers
register both descriptors and clients discover them only through explicitly
permitted catalog entries. No provider IDs, calendar account implementation or
recording-specific routes are required by consumers. Mac Calendar is the host's
own local provider; Google remains independently packaged.

| Action | Input | Output |
| --- | --- | --- |
| `list_calendar_events` | `start`, `end`: Unix seconds; `offset`: whole number 0–10000 | `events`: JSON array; `next`: next offset or -1; `total`; `observed_at`: Unix seconds |
| `read_calendar_event` | `reference`: JSON opaque identity | `event`: JSON or empty string; `status`: found / missing; `observed_at`: Unix seconds |

Both actions are read-only, cancellable and have a 60-second timeout. Use the
SDK descriptors rather than approximating schemas: the consumer requires exact
input/output schemas, readOnly effect, cancellation and timeout at most 60 s.
Provider display titles may differ. Every request has a fresh UUID and follows
the host's normal identity, review, cancellation and permission rules.

`PluginCalendarReference` contains **calendar, event, occurrence**. Each is an
opaque nonempty string, at most 512 UTF-8 bytes; encoded reference ≤1800 bytes.
Never infer identity from a title, current start time or series name. A linked
occurrence may move; its original identity must stay the same. Cross-calendar
copies/moves and ambiguous identities require user-directed relinking.

`PluginCalendarEvent` contains the reference, title (≤180 UTF-8 bytes), calendar
name (≤120), start/end Unix seconds, allDay and optional event / meeting URLs.
The whole encoded event is ≤1900 bytes. URLs must be HTTPS with a host, no
embedded credentials and ≤500 bytes; providers strip unsuitable links rather
than inventing URLs. Dates are finite in roughly 1900–2101, end ≥ start.

A list page contains at most six events and 2048 UTF-8 bytes. Larger events can
reduce the row count. Total events are bounded at 10000; the range is at most
172800 seconds. Use calendar-local midnight boundaries for a selected date,
including 23/25-hour daylight-saving days. Providers reject malformed ranges,
wrong identifiers, revoked services and stale account state. Consumers discard
late/cancelled results, changed grants and stale metadata.

## Provider responsibilities

Mac Calendar uses existing EventKit full access, enabled calendars and hide
settings; SDK reads do not trigger an OS permission prompt. It stores calendar
ID plus external UID when available, otherwise the native event ID; recurring
identity uses the original occurrence date. Resolution rejects ambiguous
copies. The bounded original-date search spans -3 / +4 days; moved detached
events farther away depend on EventKit's direct external-ID lookup and may need
manual relinking. Native IDs can change when an event moves calendars. No
undocumented native Calendar URL is fabricated.

Google uses existing **calendar.readonly**, enabled services and selected
calendars. It resolves exact calendar / event IDs with Events.get and validates
originalStartTime for recurrence; all-day recurrence uses its original date
string so identity does not change with local time zone. Reads do not change
the plugin's displayed date. Provider settings, OAuth, Keychain and API
requests remain entirely inside Google. No attendees or event bodies are
returned by this adapter.

The identity design follows [Apple's external-identifier documentation](https://developer.apple.com/documentation/eventkit/ekcalendaritem/calendaritemexternalidentifier?language=objc),
[Apple's eventIdentifier limits](https://developer.apple.com/documentation/EventKit/EKEvent/eventIdentifier?language=objc)
and [Google's event fields](https://developers.google.com/workspace/calendar/api/v3/reference/events).
Exact Google resolution uses [Events.get](https://developers.google.com/workspace/calendar/api/v3/reference/events/get).

## Optional local attachments

Voice 0.13.1 is the first client. It stores one optional `calendar-link.json`
next to the parent meeting's artifacts. Link/change/unlink never rewrite audio,
transcripts or notebook data; a bounded previous attachment supports recovery.
Missing/unavailable events retain the last snapshot. Selecting an event does
not start recording, grant an assistant meeting access, upload audio or edit
the calendar. Opening an event revalidates its exact identity and HTTPS URL.
Other independent products may use the same adapter without Voice installed.

See [Voice usage and limits](../../NeroNook-Voice/docs/CALENDAR-MEETINGS.md) and
[verification](../../NeroNook-Voice/reports/calendar-links-2026-10-13/README.md).
