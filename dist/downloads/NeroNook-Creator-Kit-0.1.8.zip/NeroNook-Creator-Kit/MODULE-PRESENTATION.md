# Module presentation contract — host 0.11.0

A module has one **16:9 interface**, followed by a **single-line status strip**. The module selector has a separate edge handle; its expanded rail temporarily overlays the interface. Neither long text, more cards nor a different selected module may grow the outer frame. Overflow scrolls inside the interface. Camera frames fit inside their media region without cropping; the 16:9 rule describes the entire module interface, not the camera alone.

NeroNook owns the geometry, left/right selector, per-monitor active choice, hover reopening, generic rendering and visibility delivery. In 0.21.0 the collapsed selector reserves 24 points plus a 12-point gap; its 156-point rail reveals on hover without resizing a running module. Since 0.21.1, Customize opens a separate resizable host window scoped to the originating display; the Nook keeps its normal module viewport and selected content. The status strip reserves 30 points. The stage uses the monitor's configured nook width with a 900-point legibility floor, then fits within the screen's width, height and safe area. Available height can reduce the width. Normal supported monitor sizes preserve the interface ratio.

Native plugin authors supply `title`, `status`, `activity`, optional panels/media, metrics and actions. `activity` is the module-controlled single-line status (100 characters maximum); longer text truncates visually. Controls remain in a bottom row, summary details scroll independently, and panel detail cards scroll inside the media/detail region. An older snapshot remains usable in this same frame without rebuilding its plugin.

Only the chosen module has a presented view on that screen. Cameras receive the existing aggregate visibility signal: another screen still showing that camera keeps it running. Background status and notifications can continue while the module is not selected. Every monitor saves its own choice; removal or disabled/hidden modules reconcile to an available choice. The host still runs with no installed plugins.

Google is now an independent plugin. Nook is the module/workflow workspace; Tray and Automations are separate navigation. Workspace placement and ordering remain host-owned preferences, independent of plugin configuration and package installation.

## Content and settings

Tabs represent the things people use: Mouse / Keyboard, rooms, favorites, scenes, or meaningful content views. Connection, setup, credentials, diagnostics and source health belong in the plugin settings window, not a dedicated module tab. Use the existing small badge and single-line status to surface connection problems, with a settings action for resolution. This applies to new modules now; older plugin layouts will be migrated in a separate cleanup pass.

## Optional artwork-v1

The host advertises `artwork-v1` in hello. New plugins may supply:

- `PluginSnapshot.iconPNG`: original package/module icon, displayed beside its name and in the selector.
- `PluginSection.imagePNG`: original illustrations or device-reported visualizations beside card text.
- `PluginField.symbol` and `PluginAction.symbol`: optional system symbol names (80 characters maximum).

These are generic display fields. Device identity, interpretation, illustration generation and all controls stay in the plugin. No Bambu identifiers or artwork are built into NeroNook.

PNG artwork is optional, at most 8 KiB per image and 80 KiB combined per snapshot. The host checks PNG type and 1–256 pixel dimensions before decoding; invalid artwork falls back to text/icons. All messages must still fit the existing **128 KiB encoded JSON line** limit, including base64 images and text. Avoid sending many large repeated images. The Bambu fixture verifies a 12-slot plus 10-hotend snapshot with its current original 64-pixel artwork. Do not embed URLs, credentials, raw account data, code or device commands in artwork or status.

Legacy hosts ignore optional fields; feature negotiation lets plugins omit artwork for them. This is a presentation capability, not a new permission or action-execution pathway.

## Optional diagrams-v1 — host 0.11.1

A panel may supply `diagrams: [PluginDiagram]` when the host advertises `diagrams-v1`. These are passive, plugin-authored vector scenes: boxes, ellipses, lines and text. The host provides a page picker and scales the selected scene into the available panel area. Diagram panels use the full interface width; Camera retains its summary column. The outer 16:9 interface and status strip are unchanged.

Each scene has a stable ID, page title, dimensions and a plain-language accessibility summary. The host bounds scene/page counts, dimensions, finite coordinates, text length, fonts, line weights and strict hexadecimal colors before rendering. There are no scripts, remote resources, file paths, device identifiers or actions in a vector element. Existing reviewed actions retain their separate protocol path. Maximums: 10 scenes/panel, 300 elements/scene, 2,400×1,600 logical points and the existing 128 KiB encoded-message limit. Backward-compatible plugins retain their section fallback when this capability is absent.

All hardware interpretation and drawing composition stays in each independent plugin. NeroNook has no printer-specific renderer or dependency on a Bambu package.

## Optional control-cards-v1 — host 0.13.0

Interactive module interfaces use optional `PluginPanel.cards` (`PluginControlCard`) instead of passive diagrams. The generic host renders a searchable, scrollable card grid inside the same 16:9 stage, with a group picker from card subtitles. Each card supplies bounded text, an optional system symbol, highlight state, and up to three opaque `PluginAction` buttons. An action's optional `confirmation` is reviewed inside its card; Cancel sends nothing, and a changed or disabled action invalidates the review. Results remain in the module's status. Setup stays behind the settings gear.

The host routes only an enabled action advertised by the current snapshot. Plugins must independently validate the action, current connection, target and allowed controls before execution. Card interaction uses the existing `action` message, without parameters, credentials, device APIs or provider-specific code in the host. Cross-plugin `actions-v1` grants/review remain separate and unchanged.

Bounds: at most 96 cards/panel, 192 total/snapshot, three actions/card, 400 characters/confirmation, unique card IDs per panel, and consistent definitions when the same action appears in multiple panels. The existing 128 KiB encoded-message limit still applies. Cards cannot mix with media or diagrams in the same panel. Plugins must negotiate `control-cards-v1` and supply their previous presentation to older hosts. Existing plugin packages remain compatible without rebuilds.

## Optional collections-v1 — host 0.19.0

Use [native collections](COLLECTIONS.md) for calendars, inboxes, task lists and file browsers. These use a semantic native layout inside the same fixed stage, with provider-owned data/actions and older-host fallbacks.

### Static module identity
[Manifest icons](ICONS.md) are available in 0.20.1 and take precedence over snapshot artwork. They work before launch and while stopped. Each independent plugin owns its symbol, color and optional badge.
