# Editable module forms · forms-v1

Negotiate `forms-v1` and `actions-v1` in both hello and ready. Older hosts ignore the optional `PluginPanel.forms`; supply a useful legacy panel or settings window when the feature is absent. Existing button/card protocols are unchanged.

A panel can contain one to four forms instead of cards, diagrams or video. Each form has an ID, title, revision, enabled state, a complete registered action definition and up to six inputs. Register that exact action through actions-v1 before publishing its form. Text, number, bounded slider, toggle and string choice inputs are supported. Fields match the action schema exactly. Choices and finite numeric limits are validated on both schema and submission. Snapshots keep the existing 128 KiB frame limit.

The host keeps drafts per displayed view. Editing never sends a command. Submit validates against the current enabled form and registered action, then creates an immutable run through the shared action router. Read-only actions execute immediately; local/external changes enter in-card review. Cancel before confirmation executes nothing. Confirmation rechecks the current form, provider session, action definition and arguments. A new form revision, changed definition, disconnect, timeout or removal invalidates pending review. Settings and the card show the same run and history. Running commands follow their declared cancellation capability; no retries or generic undo are implied.

Providers must change `revision` when their target or relevant resource state changes and must independently recheck freshness, target identity and domain constraints on execute. Keep revisions stable during unrelated status refreshes so drafts remain useful. Hosts cannot establish the truth of a device state from its display label.

Do not put secrets in forms: values appear in snapshots and review UI. Authentication and credentials remain in plugin-owned settings. Run history retains identity/outcome without input or returned values. A native plugin is trusted executable code; this contract is not a device or filesystem sandbox.

The native creator starter demonstrates an editable demo count and status. `edit_demo` checks whole-number semantics and its own text limit again before applying. This action is also available through the same SDK catalog to authorized automation clients.
