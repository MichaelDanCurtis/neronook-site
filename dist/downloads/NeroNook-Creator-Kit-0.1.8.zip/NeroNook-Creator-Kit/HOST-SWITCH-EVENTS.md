# Keyboard channel observations

An optional convention on the existing shared action/event bus; no host plugin IDs, hardware driver, or monitor transport is required. A keyboard provider and a monitor consumer remain independently built products. Their normal features work without this connection.

A provider may register `host_switch_choices` as an event channel with `event_id` (UUID string), `device` (exact opaque identity), `channel` (whole number 1–3) and `observed_at` (Unix seconds). Its event request UUID must equal `event_id`. It may also register `host_switch_status` as a state channel with `device`, `name`, `watching` and `supported` booleans. Status announces the selected watched keyboard; it is not a physical key press. `supported` means the provider can open its observation API, not that every keyboard supports firmware capture.

The user grants both named channels to a chosen consumer in Settings → Modules. Discover and subscribe through the SDK catalog, which includes permitted exports only. A package/definition update invalidates its pinned grants; renew only the intended channels. State deliveries and event deliveries both arrive as `bus.operation == event`.

Providers require an explicit watch, publish only actual fresh observations, preserve normal host switching, and keep a quiet initial/reconnect baseline. No ordinary typing is captured. Consumers bind an explicit keyboard and target, let the user edit the channel mappings, and require confirmation of unacknowledged source commands on that target before following. Stop follows immediately; a changed target/mapping/provider disarms the connection. Process restart requires explicit re-enabling.

For the reference consumer, UUIDs are consumed before a busy/unavailable rejection; no command queues or retries. Only whole channels 1–3, finite timestamps after arming, age ≤2 seconds and future skew ≤250 ms are accepted. A device setting request is not proof the monitor applied it; preserve that distinction in status and acceptance reports.

A host can observe presses only while the keyboard is connected there. The reference provider also publishes a measured return after observing departure in the same agent lifetime. Presses between two other computers require a publisher on an active computer. A disconnected keyboard alone never establishes which channel was chosen.
