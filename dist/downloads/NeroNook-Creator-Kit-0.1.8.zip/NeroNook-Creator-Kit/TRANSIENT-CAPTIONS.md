# Transient captions

`transient-caption-v1` is an optional, generic SDK display capability. A
plugin that sees it in `hello` may include it in `ready` and send sequenced
`PluginMessage(type: "caption", caption: ...)` updates. The host validates
identity, session, sequence and the bounded `PluginTransientCaption` before
showing anything. Older hosts ignore the capability; plugins should retain
their own display fallback.

An active caption appears in a focus-free panel aligned below the Nook on the
chosen display. It never expands the module, changes the active workspace,
receives keyboard/mouse events or opens the plugin's window. `displayNumber`
is the macOS `NSScreenNumber` when the plugin knows the target screen; the
host otherwise uses the pointer screen. Active captions expire after four
seconds without refresh. A result expires after five seconds. Send `dismiss`
on cancellation; disconnect and host shutdown also clear it. Only the
currently shown plugin can dismiss its own caption.

Titles, details and text are limited to 80 characters, 160 characters and
1,200 UTF-8 bytes respectively. This surface is display-only. It conveys no
input, action authority, microphone access or editor content to a plugin.
Authors should send only content the user explicitly chose to show, avoid
credentials, and keep a useful fallback on hosts without negotiation.
