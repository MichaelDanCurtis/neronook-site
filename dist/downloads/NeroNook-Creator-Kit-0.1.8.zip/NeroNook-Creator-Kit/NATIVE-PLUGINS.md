# Native plugin interface 1

NeroNook contains generic display and lifecycle infrastructure. Native integrations are separate signed `.app` packages, installed in Settings → Modules → Install or Update Plugin. No host rebuild is required. The host does not name, import or link individual integrations.

Simple local tools can continue using the managed JavaScript module runner. Native plugins are trusted application code, not confined by that runner's sandbox. A process boundary provides crash isolation, not filesystem/network containment. The installation review states this explicitly.

## Independent SDK

`NookPluginSDK` is a small Swift package containing Codable protocol models, bounded newline framing, display fields/actions, lightweight module models, and plugin-scoped storage/Keychain helpers. A plugin can vendor a versioned copy, or implement the JSON contract in another language. It does not need the NeroNook executable or its source checkout to compile or run its own tests.

## Package

The app's `Contents/Resources/NookPlugin.json` declares `id`, `name`, `version`, `apiVersion: 1`, `summary`, and human-readable `capabilities`. Its `id` must match `CFBundleIdentifier`; `CFBundleExecutable` identifies its executable. The host checks the signature, validates the manifest and pins the complete bundle contents. Updates require a new review; an altered installed bundle will not launch. Signature validity does not establish publisher trust or notarization. Preview packages are limited to 128 MB and 4096 regular files, without bundle symlinks.

The host copies each installation/update into a new private installation directory. Monitor placement, enabled state and compact-activity preference survive an update. Removing a plugin stops it and removes its registration; plugin-owned settings, credentials and previous package files remain for recovery. Old-package garbage collection is not implemented yet.

## Process protocol

The host launches the executable with `--neronook-plugin`. Standard input/output carry UTF-8 newline-delimited JSON, bounded to 128 KiB per message. Standard error is discarded. The environment is reduced to normal system path, home and temporary-directory values. No host credentials, account tokens, script APIs or device configuration are passed.

Every message contains `apiVersion`, `type`, `pluginID`, `session` (UUID), and `sequence`. The host sends `hello` with a fresh session. The plugin must respond with `ready` for that exact identity/session at sequence zero. Thereafter it sends `snapshot`, negotiated `frame`/`bus`, or `heartbeat` with strictly increasing sequence numbers. Missing messages for 15 seconds stop the plugin; malformed, oversized, repeated or mismatched messages also stop it. No automatic command retries occur. Sleep stops workers; wake starts a fresh session for enabled plugins.

A snapshot contains `title`, `status`, `activity`, optional 0–100 `progress`, `fields: [{label,value}]`, and `actions: [{id,label,enabled}]`. Counts and string lengths are bounded by the SDK. The host renders these ordinary values as native text/controls. Separately negotiated custom-views-v1 panels may render bundled plugin UI in WebKit; see [custom views](CUSTOM-VIEWS.md). Clicking an enabled declared action sends an `action` message with its ID. `configure` is the standard settings action. A plugin handles the request in its own process and performs any needed action review and domain validation.

Optional feature negotiation in `hello`/`ready` advertises `dashboard-v1` and `inline-media-v1`. Dashboard snapshots may add `badge`, `metrics`, `sections` and `media` label/status. Older peers ignore absent/unknown optional fields. Rich snapshots must retain meaningful ordinary fields as fallback.

When both peers support inline media, the host sends `visibility` with `visible` reflecting whether any selected display presents the plugin. The plugin should start/stop preview work accordingly. A `frame` message contains `frame: {jpeg: <base64>}`. Encoded JPEG is at most 65,536 bytes, dimensions at most 1280×720, within the normal 128 KiB line bound. The host bounds image decoding, processes at most approximately eight frames per second and discards stale images after five seconds. Plugins should send at most four frames per second and reduce resolution/quality to fit. Invalid image content is rejected. The plugin owns camera transports and codecs; the host receives display-only bytes.

Native settings and consequential reviews remain plugin-owned windows. The host knows nothing about printer protocols, camera ports or account sessions.

## Verification

Run `scripts/test-native-plugins.sh` with a macOS SDK. It compiles standalone fixture plugins and the actual host runtime, then tests handshake, install/update, action routing, profile persistence, disable/restart/removal, crash isolation, invalid identity, duplicate sequence, oversized output, timeout, inline JPEG validation and multi-display visibility. It never connects to a device. Existing lightweight-runner sandbox tests remain separate.

This is a local developer preview. Marketplace signing/trust, notarization, automatic update delivery, stronger native-plugin containment, and selection of a redistribution license remain release work.

## Dashboard panels (0.10.1)

The optional `panels-v1` feature allows a snapshot to supply `panels: [{id,title,usesMedia,sections}]`. The host renders a segmented picker above the same fixed-size dashboard stage. A media panel displays the negotiated frame stream; other panels display native, scrollable section cards. Each display maintains its own selection for the lifetime of the view. Only selected media panels contribute to the aggregate camera visibility signal. Snapshot fields/metrics and reviewed action buttons remain outside the switching stage. Legacy peers retain the ordinary media/sections layout.

Panels are limited to six unique valid IDs with 40-character titles. Each panel allows twelve sections with 80-character titles and 1,200-character details. The ordinary message size limit still applies. Panel titles and data are plugin-defined; the host contains no device-specific tab names or data parsing.

## Shared action and event contract (0.12.0)

The optional `actions-v1` feature adds generic registration, discovery, invocation, typed results, cancellation, events and fresh-state subscriptions. The SDK defines the contract and NeroNook enforces routing, grants and exact-run review. See [ACTIONS.md](ACTIONS.md). No vendor integration belongs in this infrastructure.

## Independent application lifecycle (0.14.0)

Native manifests may opt into `"launchMode": "application"`; omitted values retain the original stdio worker behavior. Unknown modes are rejected. This generic mode is for plugins whose native framework permissions or window lifecycle require LaunchServices. The host never imports their frameworks or adopts their entitlements.

NeroNook launches the exact reviewed bundle as a new background application instance using `NSWorkspace.OpenConfiguration`. The app receives `--neronook-plugin`, an ephemeral `NERONOOK_PLUGIN_PORT` and a per-launch `NERONOOK_PLUGIN_TOKEN` in its process environment. The SDK's `PluginApplicationChannel` connects only to IPv4 loopback, authenticates first, then carries the same bounded newline messages, session, feature negotiation and monotonically increasing sequences. It must be retained for the session; start it eagerly even when no window is visible. `nil` from the receive callback means the connection ended; shut down hosted work. No account/device credentials travel in this launch environment.

The host listener binds only `127.0.0.1`, accepts at most four pending candidates, limits authentication to 256 bytes/three seconds, sends no protocol data before the matching nonce, and closes its listener after authentication. Each send queue is bounded to 8 MiB; standard message and heartbeat limits still apply. No network discovery or LAN listener is created. This protects against accidental or unauthenticated connections; trusted native plugins and the same-user local machine remain outside the lightweight sandbox security boundary.

Disable, removal, update, sleep and host shutdown close the connection and terminate the launched application; a nonresponsive app is forcibly stopped after the existing two-second grace period. Reconnection starts a new session and never replays commands. Plugins own their settings-window behavior and must keep their published heartbeat responsive while hidden, without preventing normal machine sleep.

This mode requires NeroNook 0.14+. Plugins supporting older hosts must avoid privacy-sensitive startup on the old stdio path and display an update-required state. A plugin installed with a new manifest field by an older host must be re-reviewed on the newer host before running, because the persisted reviewed manifest did not contain that field.

Automated checks cover authenticated SDK round-trip, host shutdown/SDK EOF, rejection of an incorrect nonce before protocol output, manifest backward compatibility, and the existing actual-host zero-plugin/stdio lifecycle suite. Application-framework permissions and hidden-window behavior still require a signed, installed-app check.
