# Built-in services on the shared action bus

The `local.neronook.*` namespace is reserved for host-owned services and cannot be installed as a native plugin. Ordinary plugins still discover and use these services through actions-v1, with the same signature-bound permissions, schema validation, review, deadlines, cancellation and history as other providers. No private Stream Deck or agent route is provided.

In host 0.17.0, Automations is a consumer and a provider of saved manual workflow actions. Workflow action identities include a digest of the full graph, so editing a workflow invalidates callers' old action selection. Nook utilities supplies local notices and chosen Shortcut actions. Providers remain optional: a workflow that references a missing plugin is unresolved, and the rest of the host continues to operate.

The in-Nook module surface can now show router-owned reviews for cross-plugin proposals. Forms can show supplementary sections, such as a streamed conversation, inside the same scrollable 16:9 stage. Neither addition lets a provider approve its own request or change its reviewed arguments.

## Workspace context · host 0.22.0

`local.neronook.workspace` is an optional read-only provider for any actions-v1 caller. The owner grants each capability in Modules → Actions and connections; no plugin receives it implicitly. It works with zero installed plugins and has no vendor or assistant-specific route.

| Action | Returned information |
| --- | --- |
| `read_workspace` | Connected display names and effective selected workspace destinations, using the same visibility/order/fallback rules as the Nook |
| `read_modules` | Installed module identity/name/version/enabled/runtime status; no module payloads or credentials |
| `read_workflows` | Saved workflow names, IDs, step counts and armed state; no graph arguments |
| `read_runs` | Active-first workflow/action progress, phase and current step; no action arguments or returned values |

Each action accepts an optional nonnegative whole-number `offset` (default zero). Output is `items` (a JSON array encoded as a string, at most 1,800 UTF-8 bytes), `next` (the next offset, or -1), `total`, and `observed_at` (ISO 8601). Pages contain at most eight items. They are fresh observations, not an atomic snapshot across pages; lists can change between reads. Run history is bounded to the host's retained records. Installation inventory does not authorize reading those modules' content; their separate action/channel grants still apply.

Assistant clients must separately explain when returned workspace metadata is sent to a cloud model. A SDK grant authorizes local routing, not hidden background sharing.
