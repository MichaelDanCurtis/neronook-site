# Plugin-owned windows and custom views · host 0.20.0

Plugins are not restricted to the SDK's cards or collections. There are two supported paths:

- **Standalone native windows:** arbitrary SwiftUI/AppKit views in the plugin process. Use standard `WindowGroup`/`NSWindow`, or retain the SDK's `PluginWindows` helper to open/reuse named windows. Native entitlements, permissions and window lifecycle belong to the plugin.
- **Custom views inside the Nook:** optional `custom-views-v1` panels, authored as local HTML/CSS/JavaScript (including a bundled React build). The same `PluginWebSurface` can be used in the plugin's own window. This is a WebKit view; it does not dynamically load plugin SwiftUI classes into NeroNook.

NeroNook keeps the 16:9 stage, separate status line, monitor selector and settings access. A plugin supplies its own layout, controls, state and behavior without host-specific implementation or a host rebuild. Each mounted view has independent browser state. Unmounting tears down that WebKit view; durable state must live in the plugin.

## Package and negotiate

Put assets under `Resources/Views/`, for example `studio/index.html`, `studio/studio.css`, and `studio/studio.js`. The creator packager copies this directory into the independently signed app. Assets must be normal files: no symlinks, traversal, absolute paths or remote entry URLs. Supported types are HTML, CSS, JS, JSON, SVG, PNG, JPEG, WebP and WOFF/WOFF2. Per-file limit is 2 MiB; package view assets are limited to 512 files and 32 MiB. The renderer also bounds cumulative requests/bytes per mounted document.

After receiving `custom-views-v1` in hello, return it in ready and publish:

```swift
let view = PluginCustomView(
    entry: "studio/index.html", revision: "layout1",
    state: ["title": .string("My workspace")],
    events: [.init("rename", input: .init([.init("title", .string)]))]
)
let panel = PluginPanel("studio", "Studio", customView: view)
```

Use the existing cards/sections or an action opening the standalone window as fallback when the feature is absent. A panel cannot combine a custom view with forms, cards, collections, diagrams or media. Update `revision` when the view's interaction contract changes. State updates do not reload the page or destroy field focus.

## View bridge

```javascript
nero.onState(state => {
  document.querySelector('h1').textContent = state.title || '';
});
await nero.emit('rename', { title: 'New title' });
```

`nero.state` is the latest published state. `onState` immediately calls the callback and returns an unsubscribe function. State is a bounded dictionary of strings, finite numbers and booleans (64 keys / 32 KiB). For richer structures, serialize a bounded structure into a string field and parse it in your own view. Use textContent or equivalent escaping for untrusted remote text.

`emit` produces an identity/session-bound `viewEvent` with `panelID`, `revision`, `name`, and typed `values`. The host validates it against the **current** snapshot before sending it to the same plugin process. Schemas use the existing `PluginValueSchema`; event count, body size and frequency are bounded. The promise acknowledges delivery to the plugin connection, **not completion of an operation**. Publish results/errors/progress in subsequent view state; do not show success solely from the promise.

The plugin must revalidate the exact panel, revision, event schema and domain values before acting:

```swift
guard message.type == "viewEvent", let event = message.viewEvent,
      event.panelID == "studio" else { return }
try currentView.validate(event)
// Interpret the event in this plugin, then publish updated state.
```

An event does not grant access to other modules, AI, automation, files or credentials. Cross-plugin actions continue through the existing actions-v1 permission/review path. Consequential operations owned by the plugin need its own appropriate review, just like existing native plugin buttons. Do not put secrets in view state.

## Standalone windows

```swift
// Retain this in the plugin model.
let windows = PluginWindows()
windows.show("inspector", title: "My inspector") {
    MyOwnSwiftUIView()
}
// Or use the same bundled custom view:
PluginWebSurface(root: Bundle.main.resourceURL!.appendingPathComponent("Views"),
                 panelID: "studio", definition: currentView) { event in
    try handle(event)
}
```

The helper defaults to an 800×450 resizable window. Reusing an ID brings that window forward. `close(id)` and `closeAll()` release retained windows. Plugins may use ordinary platform windows directly for more specialized behavior.

## Runtime boundary

Bundled assets load through a local custom scheme with a nonpersistent WebKit data store. There is no host filesystem bridge, arbitrary URL opener, shell function or direct network API. Content policy blocks network connections, frames, forms, workers and external resources; navigation stays in the entry document, popup windows are blocked and web camera/microphone requests are denied. Networking and authenticated operations stay in the plugin's native process and return bounded state through the existing protocol. Downloads/file-pickers are not an SDK capability of this surface.

Native plugin code is still trusted application code and not a filesystem/network sandbox. WebKit content limits do not change that established installation model. Web-process failure shows a local error; it does not retry commands. Restart the module to recover a failed view.

## Working example and validation

New creator projects include a **Custom view** tab, independent local CSS/JS assets, typed mode/name events and an **Open native window** control. The latter opens a completely custom SwiftUI window in the plugin process. The original dashboard and legacy fallback remain available. `python3 Tools/nook.py test .` validates standalone compilation and old/new handshakes; it does not prove rendering. Install a separately signed example and inspect its view, input focus, state updates, window opening and stop/restart behavior in the actual Nook.

Implementation uses Apple's public [WKURLSchemeHandler](https://developer.apple.com/documentation/webkit/wkurlschemehandler) and [WKScriptMessageHandlerWithReply](https://developer.apple.com/documentation/webkit/wkscriptmessagehandlerwithreply) APIs. Public distribution/notarization and third-party clean-machine acceptance remain separate gates.

## Reveal a plugin from a user gesture · host 0.23.0

Negotiate `presentation-v1` in hello/ready. After an explicit user gesture, a plugin may emit a normally sequenced `PluginMessage(type: "present", pluginID: ..., session: ..., sequence: ...)`. The host reveals only that authenticated plugin's own workspace destination. It chooses the enabled display at the pointer, or another display where the plugin is visible. Disabled hosts/plugins and destinations removed from every workspace remain hidden. Presentation never adds a destination or changes its visibility settings.

Requests use normal session/sequence checks and a per-plugin one-second throttle (`PluginPresentationGate`). There is no arbitrary target, executable payload, review bypass or new data grant. Do not emit presentation requests from timers or background status updates. A hardware menu key is one intended caller; the protocol is available to any independent plugin. Older hosts omit the feature, so use a plugin-owned window as fallback. Presentation is best effort and currently has no acknowledgement.

## Plugin-supplied raster imagery · host 0.25.0

`view-resources-v1` adds live raster resources to a bundled custom view without granting WebKit network access. Networking, authentication, provider policies and caching remain in the independent plugin. The host forwards opaque paths and validates returned bytes; it contains no map/provider implementation.

Negotiate both `custom-views-v1` and `view-resources-v1`. Declare up to four `resourceNamespaces` on `PluginCustomView`, for example `["images"]`. An image at `nook-view://surface/_plugin/images/preview/123` becomes a `viewResource` message containing a `PluginViewResourceRequest` (`id`, `panelID`, `revision`, `path`). The plugin must validate its current panel/revision/namespace and its own domain-specific path rules before resolving the resource. Paths are not URLs and cannot traverse directories.

Respond with a normally sequenced `viewResourceResult` carrying `PluginViewResourceResult(id:mime:data:)`, or `error:` alone. Supported responses are single-frame PNG/JPEG/WebP, at most 64 KiB and 2,048 pixels in either dimension. Declared MIME must match the encoded image. HTML, SVG, scripts and arbitrary files are not dynamic resources. The existing bundled-asset mechanism still supports static SVG.

The renderer admits 12 concurrent requests per view, queues at most 512, and limits each mounted view to 1,200 requests / 32 MiB per minute. Host transport limits are 48 pending requests per plugin, 128 globally, with a 15-second deadline after dispatch. `viewResourceCancel` carries the request UUID. Cancel your corresponding native task; never publish a canceled response. Late responses cannot revive closed views. View teardown, revision replacement, plugin disable/restart and host shutdown cancel pending work. The broker verifies plugin identity and process session before resolving a request.

For an independent native window, provide the same handler directly:

```swift
PluginWebSurface(root: viewsRoot, panelID: "preview", definition: currentView,
                 onResource: { try await provider.resource($0) }) { event in
    try handle(event)
}
```

Use advertised frame identifiers, fixed provider rules, bounded responses, ordinary HTTP caching and on-screen demand in your provider. Avoid refreshing or prefetching imagery while the view is hidden. Older hosts should receive the existing diagrams/cards or an action opening the independent window. No plugin becomes a build or runtime dependency of NeroNook.

## Isolated plugin documents (host 0.26.0)

Negotiate `isolated-frames-v1` before including `PluginCustomView.frames`. Up to two `PluginViewFrame(url:)` documents may be declared. Each must be an exact HTTP URL at literal `127.0.0.1`, a nonprivileged explicit port, and a normal `.html` path. Credentials, query strings, encoded paths and fragments in declarations are rejected. Frame navigation permits only that exact URL and its fragment updates. Host page navigation, popup windows, downloads, file selection, camera/microphone access and the native event bridge remain unavailable to subframes. The main custom view keeps its existing no-network policy; only declared frame origins enter `frame-src`.

This supports a provider library inside a separate document without giving that library the host's tools. The plugin owns any server, remote provider, authentication, configuration and lifetime. Bind only to loopback, require a random per-process capability path, validate Host/method/path, disable CORS and caching, and stop the server with the plugin. Never put a provider key in snapshots or frame URLs. Declare the connection and secret storage in package capabilities. Use `sandbox="allow-scripts allow-same-origin"` on the iframe and a restrictive CSP on the served document. Keep provider branding and licensing visible. Removing the iframe should release its network/rendering work. Changing the declared frame list reloads the custom view and revokes the previous navigation destinations.

Older hosts must receive a view without frames and a useful setup/open-window explanation. Native plugin windows can use the identical `PluginWebSurface` and vendored SDK independently of a host checkout. No vendor-specific implementation belongs in NeroNook.

### Public HTTPS documents (host 0.26.1)

Negotiate both `isolated-frames-v1` and `https-frames-v1` before declaring a public HTTPS `PluginViewFrame`. HTTPS URLs must use a public DNS-style hostname and standard port, with an exact normal path (including `/`). Declarations reject credentials, query strings, fragments, encoded paths, IP addresses and local hostnames. Fragment navigation is allowed; different paths, origins, schemes and ports are not. Loopback-only clients keep their existing v1 behavior. This remains a maximum of two documents total, not two per kind.

The page is displayed as third-party web content: it gets neither the native event bridge nor parent view state. The SDK uses an ephemeral WebKit store and denies popups, downloads, file selection and camera/microphone access. The plugin must sandbox its iframe (`allow-scripts allow-same-origin`), disable geolocation and use a no-referrer policy. Do not add top-navigation, forms or popup permissions. Remove the iframe when hidden and preserve the site's branding, controls and data attribution. Showing a public site is not an API contract or a production redistribution license; plugin authors remain responsible for the provider's supported usage.

Providers and account setup belong to the independent plugin. The host has no provider names, credentials or vendor-specific code. On hosts without HTTPS negotiation, omit remote frames and offer the plugin's separate window or an explicit upgrade message.
