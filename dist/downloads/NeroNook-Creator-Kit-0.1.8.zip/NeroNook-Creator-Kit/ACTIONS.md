Optional adapters built on this unchanged transport: [shared speech](SPEECH.md)
[cited answers from explicitly supplied text](EVIDENCE-ANSWERS.md), and
[read-only calendar metadata](CALENDAR.md).

# Shared actions and events — actions-v1

Available in NeroNook 0.12.0. This optional native-plugin SDK contract is vendor-neutral. The core implements discovery, routing, permissions, per-run review and history. Plugins own connections, settings, authentication, validation and actual execution. NeroNook runs with zero installed plugins. No module imports another module or needs its source to build.

## Negotiate and register

Both `hello` and `ready` must advertise `actions-v1`. Then send ordinary interface-1 `PluginMessage` envelopes with `type: "bus"` and a `PluginBusMessage` in `bus`. Existing session/identity/strictly increasing sequence checks and 128 KiB framing still apply. Old plugins continue using their existing protocol without this feature. The contract currently serves native plugins; exposing it to the managed JavaScript runner is future work.

Use the SDK's Codable models rather than assembling JSON by hand. A plugin registers its complete action/channel catalog using `register`. Addresses combine its installed plugin ID with a local name; another publisher's namespace cannot be used. Registration is a replacement. Changing a provider's definitions interrupts pending/running requests and invalidates grants for changed definitions.

```swift
let registration = PluginRegistration(
    actions: [PluginRegisteredAction("read_status", title: "Read status",
        output: PluginValueSchema([PluginParameter("message", .string)]))],
    channels: [PluginChannel("status", title: "Status", kind: .state,
        schema: PluginValueSchema([PluginParameter("message", .string)]))]
)
let bus = PluginBusMessage(.register, registration: registration)
// Wrap bus in the negotiated PluginMessage and write encoded() to stdout.
```

Each action declares typed input/output, effect (`readOnly`, `localChange`, `externalChange`), cancellation support and a 1–300 second timeout. Schemas contain at most 16 named scalar fields: string, finite number or Boolean, with required fields and optional numeric bounds. Unknown arguments and wrong types are rejected. Text values are limited to 2,048 UTF-8 bytes. A plugin exports at most 32 actions and 32 channels. Actions and channels have distinct grant identities even when their local names match.

## Discovery and access

`discover` returns only the caller's own exports and explicitly permitted exports from connected providers. Catalog replies arrive as a generation sharing one request UUID: an empty catalog, one entry per message, then `complete: true`. Use `PluginCatalogAccumulator`; it publishes a new catalog atomically only on completion. Disconnects, registrations and permission changes also broadcast catalogs. Discard mappings or state that are no longer present. Do not interpret a partial catalog as the available action list.

The host's Settings → Modules → Actions and connections grants individual actions and channels to callers. Grants are pinned to both installed package fingerprints and the exact descriptor. Updating either package requires renewed cross-plugin access. A plugin cannot grant itself access to another plugin. Its own exports are accessible automatically. Corrupt permission storage fails closed.

Native plugins are trusted executable code, not sandboxes. These permissions control SDK routing; they cannot prevent a native plugin from accessing services itself. The provider must accurately declare effects and enforce domain-specific checks and authorization.

## Invoke, review and execute

A caller sends `invoke` with a fresh UUID, address and typed values. Reusing a run UUID never retries the action. The core validates availability, permissions and schema. Read-only actions start immediately; actions changing local or external state wait for the user to review the exact request in NeroNook. Approval is tied to immutable arguments and the current caller/provider sessions, descriptor, permission and deadline. Reviews expire after two minutes.

Only the core sends `execute` to the provider. The provider validates its current target and service state before acting, then responds with `update` using the same run UUID. Report progress in 0–1 only when measured, a brief message and the eventual `succeeded`, `failed`, `cancelled` or `interrupted` result. `interrupted` means the provider cannot establish the outcome. Only success carries output values, which must match the declared output schema. The core rejects foreign-provider updates, late results and invalid transitions. Requesters receive status via `update`; protocol/permission failures use `failure`.

`cancel` from a caller applies only to its own run. Before execution it declines the request. During execution it sends a cancellation request to a provider that declares support, and shows `cancelling` until a result arrives. Cancellation is not proof that a device stopped. Disconnect, revocation, definition change or timeout ends the run as `interrupted`, with an unknown-outcome warning when execution might have started. Nothing is automatically replayed after reconnect. Existing Bambu controls retain their plugin-owned reviews until deliberately adopted into this contract.

## Optional long-running actions — host 0.27.0

Negotiate **actions-long-running-v1** in both hello and ready before registering
an action with `completionTimeoutSeconds`. Older hosts retain the existing
actions; omit the long wait action there. The ordinary 1–300-second
`timeoutSeconds` becomes an inactivity limit for these actions. Each valid
nonterminal running update renews it, capped at the absolute completion limit
(at most 86,400 seconds, counted from execution approval). It never renews the
two-minute review or Stop deadline. A provider may report `cancelling`; later
running observations retain Cancelling in the core. Stop is delivered once and
waits at most two minutes for the provider's bound terminal outcome, then becomes
Interrupted rather than falsely claiming a remote process stopped. Ordinary
actions retain their fixed execution timeout. Registration/grants pin this
optional metadata too; changing the limit requires renewed review and grants.

Providers own polling, durable job identity, authentication and reconciliation.
Use actual stage messages when percentages are unavailable. The host owns no
service-specific request, run or cancellation code. A terminal result cannot
execute local instructions; it is typed display/data for explicitly connected
later workflow steps. Reconnect interrupts a workflow and never invokes an old
request automatically.

## Optional run display — host 0.28.0

`run-display-v1` adds optional `PluginRunUpdate.display` metadata for compact
clients such as hardware keys. `PluginRunDisplay` contains title, current step,
detail, completed/total step counts and `needsReview`. Title and step are bounded
to 80 characters, detail to 300; counts must satisfy
`0 <= completedSteps <= totalSteps <= 64`. Ordinary updates and old clients keep
working when this field is absent. The feature adds no actions or approval path.
Only the normal host review can approve execution.

The workflow provider reports actual completed graph steps and its current
review/progress detail. These counts are not a remote job's percent complete.
Consumers should show stage text or an activity indicator when no measured
percentage exists. Correlate every update and Stop with the original request
UUID; preserve Cancelling until a confirmed terminal result. Page changes are
presentation changes, not cancellation. After a lost connection, show an unknown
outcome and inspect the original provider rather than replaying the invocation.

## Events and fresh state

Register channels as `event` or `state`. An authorized consumer uses `subscribe`/`unsubscribe`; only the owner can `publish` typed values. The core delivers `event` messages. State includes a lifetime of 1–300 seconds (default 30) and is retained only until expiry. A new subscriber receives fresh retained state with its remaining lifetime. Consumers must display stale/unavailable state after expiry. Events have no lifetime and are never retained/replayed. The workflow engine will need its own trigger deduplication policy; event delivery does not provide exactly-once workflow execution.

## Limits and storage

The router bounds each peer to 64 bus messages per second, 32 subscriptions, 32 globally active runs, and 4,096 accepted invocation UUIDs per session. Catalog assembly is bounded to 1,280 entries. Outbound host input queues are bounded to 8 MiB and write off the main actor so a non-reading plugin cannot freeze the UI. Stable run IDs prevent duplicates within a live caller session and while IDs remain in bounded history; callers must never replay old invocations after restart. These are preview limits, not an unlimited event stream.

The core stores at most 100 run summaries (identity, title, outcome, date), without arguments or results, and at most 2,048 exact grants. In-memory run details are bounded and cleared on app restart. Interrupted runs are not resumed. Plugin-owned credentials stay in plugin-owned storage/Keychain. A history/permission persistence failure is visible and denies new routed access; a recovery UI remains future work.

## Verification and current consumers

Run `scripts/test-actions.sh` for schema, grants, replay, ownership, review, progress/results, cancellation, revocation, timeout, fresh state, persistence, update invalidation, disconnect and framed catalog checks. `scripts/test-native-plugins.sh` covers actual host lifecycle and old-plugin compatibility.

The independent Stream Deck module is the first consumer. Its Elgato companion supplies Run Action, Show Status, Action Menu and paired Stop Run through its own same-user Unix socket. Version 0.3.0 launches shared manual workflows, shows their reviews/step counts/elapsed time and stops only an original run that this companion owns. Native Fuego workflow completion and confirmed Stop are verified; the owner confirmed physical Run opens review, while physical Stop input remains a separate acceptance gate. All Elgato implementation stays in the plugin workspace. Arbitrary profile editing, value-adjusting dials, SDK public licensing and clean third-party installation remain separate milestones.

## Optional local speech

[Shared speech](SPEECH.md) adds a portable `speak_text` convention and cancellable consumer using the existing actions-v1 transport. It does not add provider-specific host behavior.

## Independent Fuego handoff metadata

Fuego Agent 0.2.1 uses the unchanged actions-v1 contract for its Jobs view and
optional read-only `read_job_status` / four-second `job_status` channel. Values:
`available` (Boolean), `phase`, `run_id`, `task_id` (strings), `admitted` (Boolean),
`observed_at` (milliseconds). The last field belongs to the original run read;
republishing a channel does not establish fresh progress. Consumers must inspect
that timestamp. Missing/expired channels are unavailable, and Ready compute
metadata does not establish job admission.

Version 0.3.0 adds optional `list_handoff_targets`, `prepare_handoff` and
`read_handoff_status` actions. These use the unchanged SDK: typed inputs/outputs,
exact grants and normal review. The preparation action creates an unsent draft
and returns its `review_id`; the plugin's own full review still owns Send. The
status action accepts that original ID, so changing selected jobs cannot change
the referenced handoff. An unsent draft has zero `observed_at` and no admission.
Neither action automatically sends, cancels or replays remote work.

Fuego Agent 0.4.0 adds optional `wait_for_handoff(request_id)` on the negotiated
long-running contract. Bind `prepare_handoff.review_id` to it. This action
observes the exact existing draft/job; it cannot Send. Its external-change
review authorizes cancellation of that referenced job. Send remains in Fuego's
full target/instructions review. Live stages and observation age continue until
the exact published answer, failure, or confirmed remote cancellation. Its wait
is bounded to one hour; inactivity is 30 seconds. Closing/expiring an unsent
draft finishes without starting work. Pending saved requests without a run ID
remain Cancelling until that original run can be stopped; they are not resent.

Success returns `request_id`, `run_id`, a UTF-8-bounded 2,048-byte `result` and
`result_truncated`. Full answers remain in Fuego's private handoff store. The
workflow shows results in memory for its latest run, with result details, and
does not persist them in host history. Instructions, credentials and unrelated
jobs are never exported. New wait access is off by default. No Fuego-specific
host extension or credential transfer is introduced.
