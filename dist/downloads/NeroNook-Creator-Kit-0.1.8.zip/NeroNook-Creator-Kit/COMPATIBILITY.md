**Host 0.28.0:** optional `run-display-v1` carries bounded, inert run-title,
step-count, detail and review metadata in `PluginRunUpdate.display`. Omitted
fields preserve old-client decoding. It changes neither grants nor approval;
`actions-long-running-v1` still owns completion deadlines. Stream Deck 0.3.0
vendors only these generic SDK additions. See [the contract](ACTIONS.md).

# Compatibility and migration — local SDK preview

Protocol interface 1 remains the baseline. Creator kit 0.1.8 records SDK source from host 0.28.1 and a starter minimum host of 0.20.1; kit, plugin and host versions remain separate. New display/action features are optional and negotiated in hello/ready; API version 1 alone does not mean an older host can show every new field.

The current direct-download host/sample beta contains **arm64 only**. Its declared runtime minimum is macOS 14.0; that declaration is not proof that every supported OS/hardware combination has passed. Intel is not included in this delivery. Plugin publishers choose and test their own architectures and runtime minimums. Authoring also requires a compatible full Xcode with Swift 6/XCTest and Python 3; Apple's Xcode 16/16.2 require macOS 14.5 or newer. This development-tool requirement is separate from the packaged app's runtime minimum. See [Apple's Xcode requirements](https://developer.apple.com/xcode/system-requirements).

| Feature | First host | Required fallback |
| --- | --- | --- |
| Native stdio lifecycle and ordinary fields/actions | 0.9.0 | Baseline |
| Dashboard and inline JPEG media | 0.10.0 | Ordinary status/fields/actions; plugin owns decoding and respects visibility |
| Custom plugin UI and native window helper | 0.20.0 | Negotiate custom-views-v1; retain native/card fallback |
| Focus-free transient captions | 0.26.3 | Negotiate transient-caption-v1; retain a plugin-owned display fallback |
| Dashboard panels | 0.10.1 | Ordinary fields/actions |
| Native calendar, inbox, tasks and files | 0.19.0 | Negotiate collections-v1; otherwise use previous cards/sections |
| Passive vector diagrams | 0.11.1 | Ordinary fields or sections |
| Typed actions/events and grants | 0.12.0 | Do not send bus messages or assume external action authority without negotiation |
| Bounded long-running actions | 0.27.0 | Negotiate actions-long-running-v1; omit actions with completionTimeoutSeconds on older hosts |
| Run display metadata | 0.28.0 | Negotiate run-display-v1; retain ordinary action progress and outcomes |
| Interactive cards and in-card review | 0.13.0 | Ordinary fields/actions, preserving any required confirmation |
| Editable forms backed by shared actions | 0.15.0 | Plugin-owned settings or ordinary cards; negotiate forms-v1 and actions-v1 |
| Independent application launch | 0.14.0 | Platform-sensitive plugins must report update-required on the older stdio path |

The starter demonstrates legacy fields/actions and modern control cards. Never send host-specific application code in snapshots. Validate output with the vendored SDK, respect bounded messages and give every action an exact target and honest outcome. A successful build is not host, account or hardware acceptance.

To update a vendored SDK, review its source/API change, replace the project copy, regenerate its source-hash record deliberately, run project/protocol fixtures and check the installed UI. New SDK snapshots must not silently expand plugin permissions. Plugin manifests and signed bundle contents are pinned on installation; changes require a fresh host review. Existing settings and monitor placement are retained by native updates, but application state migrations remain plugin-owned.

Content-addressed builds preserve prior app packages for explicit reviewed reinstall. This is manual recovery, not an automatic known-good rollback service. If a native installation was reviewed by an old host that ignored a new manifest field, reinstall/review it on the newer host before use. Native plugins are trusted applications; process separation isolates failure but does not provide the lightweight runner's sandbox.

Before public stability is claimed: retain the selected MIT SDK/examples notices, version release artifacts, document breaking-change policy, demonstrate an independent developer's clean install and update/recovery, finish distribution signing/notarization and verify permission-expansion decisions. These requirements do not prevent local first-party development.

## Host 0.24.0

Optional `volume-v1` negotiates typed volume endpoints, immediate gestures and confirmed results. Legacy snapshots omit `volumeEndpoints`; old plugins need no changes. See [Volume endpoints](VOLUME.md). No new cross-plugin action grant is implied by a local output selection.
