## Optional conversation extension · October 13

`PluginEvidenceChatContract` adds **answer_evidence_chat** on the unchanged
actions-v1 transport. It retains the cited-answer question/source/result schemas
and adds one required **history** string: a JSON array of up to four
`PluginEvidenceExchange` records (`question`, `answer`) totalling at most 2048
UTF-8 bytes. Individual questions ≤1024 bytes and historical answers ≤1400 bytes.
Its descriptor and grant are distinct; the old **answer_evidence** action stays
byte-for-byte unchanged. Old callers/providers continue one-question operation.

The caller owns local persistent chat and exact per-source recording/variant/
utterance fingerprints. Only supplied labels/text and recent context go to the
provider; paths, local UUIDs, audio, notebooks and library search access remain
local. History resolves follow-up references, never establishes facts. Every
new statement still requires current supplied source IDs. Reopening never
replays a request. Providers use a fresh ephemeral, tool-free request and must
not merge caller context into unrelated personal Agent chats.

Voice 0.14.1 is the first persistent / cross-document client; Agent 0.3.4 is the
first provider. Explicit preview/Send includes selected transcript text plus
the visible context. No host binary update, account transplant, implicit
permission or unrestricted transcript library tool is introduced.

The original single-request adapter remains described below.

# Cited answers from supplied text

`PluginEvidenceAnswerContract` is an optional actions-v1 adapter. It works with
the existing 0.26.3 host; no host model, provider allowlist or meeting dependency
is added. Providers and callers remain independently built products. Voice and
Agent vendor the same SDK file and record its hash in SDK-SNAPSHOT.json.

Discover a permission-scoped `answer_evidence` entry using `accepts`. Its exact
input is `question`, `snapshot`, `sources_0` through `sources_7` (only page 0 is
required). Each source page is a JSON array of `{id,label,text}`. Schema fields
remain bounded to 2 KiB. The assembled request has at most 48 unique sources,
1 KiB of question text and eight pages. Source IDs are request-local `s1`, `s2`,
etc. A caller supplies the 64-character snapshot digest. No paths, audio,
notebooks, search access or library enumeration are part of this contract.

The output field `answer` is a JSON string of at most 2 KiB:

```json
{"snapshot":"<same digest>","disposition":"answered","statements":[
  {"text":"The launch is Friday.","citations":["s1"]}
]}
```

An insufficient excerpt returns `disposition: "insufficient"` with no statements.
Every answered statement requires 1–4 distinct known IDs. Callers must validate
the output schema, request ID, snapshot and IDs, and revalidate local sources
before navigation. Never use model-generated paths, links or timestamps. The
adapter validates identity and bounds, **not factual entailment**; cited AI
interpretations still need inspection. Render text as text, never executable HTML.

The provider must describe where text is processed. The caller owns an explicit
disclosure control before invocation; a granted action alone is not consent to
send arbitrary saved material. Nero Voice previews exact selected transcript
text and invokes only after **Send excerpt & ask**. Agent uses its existing
managed ChatGPT account, a fresh ephemeral request, no context tools, no prior
chat and no action proposals. It wraps the model's statements with the caller's
snapshot locally, validates and returns them without storing meeting chat history.

Requests are cancellable and time out after 180 seconds. Retire pending requests
when source selection, permission or provider identity changes; ignore late
updates. Cancelling a request cannot recall text already sent to a service.
