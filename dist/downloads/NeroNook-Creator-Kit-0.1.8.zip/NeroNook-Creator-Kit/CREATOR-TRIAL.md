# Independent creator trial

Use the frozen Creator Kit on another Mac without the NeroNook host checkout. A successful generation/build test is useful, but independent authoring also needs the tester to change their own module, use the documentation, install/update it and report what needed help. An owner testing another physical Mac and an outside developer authoring a module are distinct results.

## Small authoring task

1. Extract the kit and run `python3 Creator/nook.py doctor .`.
2. Create a new project with your own reverse-domain ID: `python3 Creator/nook.py create /path/to/MyModule --id com.example.my-module --name "My Module"`.
3. Change the starter's default status/title in `Sources/ModuleCore/Dashboard.swift`. Give it a relevant manifest icon; see [icons](ICONS.md). Keep this trial synthetic and free of private account data.
4. From the new project run `python3 Tools/trial.py . --output build/trial-1.json --role external-creator`. This explicitly runs trusted source code through preflight/build/tests/protocol fixtures. Results stay local. Missing full Xcode or Swift 6 is an environment failure, not a plugin success.
5. Use your own stable signing certificate to preview/package: `python3 Tools/nook.py dev . --identity YOUR_CERTIFICATE`, then `pack` with the same identity. No borrowed private key or ad hoc install fallback is required or provided. If signing is unavailable, report that stage as blocked. The prebuilt signed samples can exercise the host separately.
6. Install through NeroNook's normal review; check inline action, cancelled Reset, Custom view and a separate native window. Change your plugin version, update and check preserved settings. Cancel a restore, then explicitly review one. Reopen the app and check no previous action replayed. Restoring code does not rewind plugin-owned data.
7. Record time to first module, documentation gaps, exact failures and any help received. A source change made for the tester by the host author is not independent authoring.

## Portable receipt

`Tools/trial.py` records only creator version, macOS version/build, architecture, generic model and bounded stage outcomes. It does not collect serial numbers, usernames, paths, source, environment variables, protocol payloads or credentials. Compiler output remains ordinary local developer output in the terminal. Read the result before sharing it manually. The helper never uploads, installs, accepts agreements, creates certificates or changes permissions.

Human observations may be supplied as `--observed install=pass --observed customView=fail`. Allowed checks are `install`, `inlineAction`, `cancelReview`, `customView`, `nativeWindow`, `update`, `cancelRecovery`, `restore`, `restart` and `multipleDisplays`. Allowed outcomes are `pass`, `fail` and `skipped`; omitted checks remain `not-run`. Each result uses a fresh filename. These observations are self-reported and never promoted to verified physical evidence by the tool itself.

## Compatibility coverage

Track runtime launch, signed helper/protocol, native UI, creator build, OS/toolchain and physical/virtual hardware separately. A runtime-only tester needs no development tools. Current host/sample delivery is Apple Silicon arm64; Intel requires its own build and real acceptance. External hardware displays, permissions, accounts and device integrations cannot be qualified by a virtual screen alone. Keep protected first-launch behavior enabled; record Gatekeeper failures instead of bypassing them.
