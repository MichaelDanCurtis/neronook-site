#!/usr/bin/env python3
"""Pack the developer-preview JSON envelope. NeroNook performs authoritative validation."""
import argparse
import json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('command', choices=['pack'])
parser.add_argument('folder', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
manifest = json.loads((args.folder / 'manifest.json').read_text())
manifest['script'] = (args.folder / 'main.js').read_text()
payload = json.dumps(manifest, ensure_ascii=False, indent=2).encode()
if len(payload) > 256 * 1024:
    parser.error('Package exceeds 256 KB')
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_bytes(payload)
print(f'Packed {manifest["name"]} → {args.output}')
