# Volume endpoints (`volume-v1`)

Host 0.24.0 adds an optional volume interface for independent plugins. It is generic: there are no vendor IDs, network transports or device credentials in NeroNook. Plugins still build and run independently, and zero-plugin hosts retain macOS audio controls.

## Selection and authority

The owner chooses a plugin endpoint in Settings → HUD → Volume control. The binding is stored against the current CoreAudio output UID and the plugin/endpoint IDs. Changing to another output uses that output's saved choice, defaulting to macOS. Never infer a mapping from similar device names. A missing selected plugin stays unavailable; it does not silently control another endpoint.

Only direct local volume gestures use this interface: media keys, the Nero HUD and its settings control. Selecting a volume endpoint does not grant agents, workflows or other plugins new access. Those consumers continue through the existing permission/review action bus. Neither API replaces a plugin's responsibility to validate the physical target. This interface does not change CoreAudio's native Sound slider or route audio samples through a plugin.

## Protocol

Both `hello.features` and `ready.features` must contain `volume-v1` before using its messages or snapshot field. Older hosts and plugins retain their previous behavior. SDK definitions live in `PluginVolume.swift`.

Publish `snapshot.volumeEndpoints` with at most eight unique endpoints. Use an opaque stable physical-target ID (maximum 200 UTF-8 bytes), a readable name, availability, supported volume/mute controls and confirmed state. Volume is 0–1. `observedAt` is Unix time **of the device reading**, never the snapshot's publication time. The host rejects stale or implausibly future state for control (45-second age, five-second future tolerance). Removing an endpoint disconnects it; never reuse an ID for another physical device.

The host sends `type: volumeCommand` with `volumeCommand`:

- `requestID`: unique UUID.
- `endpointID`: the exact selected target.
- `operation`: SDK enum `setVolume(Double)`, `adjustVolume(Double)`, `setMuted(Bool)` or `toggleMute`.
- `expiresAt`: Unix deadline. Validate with `command.validate()` on receipt and again before the physical write after any asynchronous device reads.

Adjustments are nonzero, bounded to ±0.25 and resolved against a fresh device read. The provider may quantize to its hardware step (Ark uses integer percentage points). Toggle also uses fresh state. Volume commands preserve mute; mute is explicit. Emit one physical setting change, then read it back. Report uncertainty honestly if the write may have applied but confirmation failed.

Reply with `type: volumeResult` and `volumeResult`, carrying the original request/endpoint IDs and either a fresh confirmed `state` or bounded `error`. Use the existing process session and strictly increasing output sequence. The host matches plugin identity, session, endpoint and request before accepting a result. It ignores old/unsolicited results and prevents older snapshots replacing newer confirmed readings.

One gesture per plugin can be in flight. While it is busy, new gestures are discarded, including repeated volume-key events. They are never accumulated, queued, retried or replayed after reconnection. The host waits up to 40 seconds for a terminal result; the shorter command deadline bounds when the provider may start a write. Disconnect invalidates pending UI ownership. An already-issued physical write can still finish; switching output/selection suppresses its completion HUD for the new target. No transactional rollback is implied.

## Host behavior and acceptance

Replace system HUD and macOS Accessibility access are required for intercepted media keys. Turning that feature off restores normal system key handling. Unsupported native audio controls pass through. HUD drags issue one plugin request on release; the displayed value follows confirmed state. A separate settings check sends the current level unchanged for read-back verification.

Tests cover legacy decoding, bounded state/commands, expiry, exact-session completion, busy input, disconnect/no replay, stale reads and output-specific persistence. Each provider must also test identity checks, fresh relative/toggle resolution, command expiry before a write, no automatic retries, real device read-back and physical key/HUD acceptance.
