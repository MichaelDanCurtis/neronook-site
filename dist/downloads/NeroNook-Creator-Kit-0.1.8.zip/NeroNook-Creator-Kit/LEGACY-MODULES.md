# Historical lightweight-module guide

The device-feed and host-owned printer sections below describe retired 0.7/0.8 behavior. For current native integrations use [NATIVE-PLUGINS.md](NATIVE-PLUGINS.md); NeroNook no longer starts device connections for these legacy packages. The local JavaScript module format remains supported.

# NeroNook plugin SDK — developer preview

Native integrations use the independent process interface in `NookPluginSDK/`. The host does not contain device-specific code. See [native plugin API](NATIVE-PLUGINS.md). The SDK provides display types, bounded framing, module types, plugin storage and Keychain helpers. Plugins may vendor a versioned SDK snapshot; they do not require the NeroNook app or its source to build.

The older lightweight module API below remains supported for local JavaScript tools. Device-feed packages from 0.8.x are retained as legacy data, but the host no longer connects devices on their behalf. The previous Bambu host-service sections are historical, superseded by the standalone Bambu plugin.

# NeroNook module API 1 — developer preview

This is a local development preview, not the signed community marketplace or stable public SDK. Modules run JavaScript in a disposable App Sandbox helper. Their views are native SwiftUI. NeroNook 0.7.0 adds an optional read-only local MQTT feed broker. Modules cannot open sockets, access credentials, send device commands, read files or access accounts. Use your own or reviewed packages only while the isolation, resource limits and signed distribution undergo wider review.

## Build your first module

Copy `Modules/HelloNook` to your own development folder. Edit `manifest.json` and `main.js`, use a unique reverse-domain ID, then run from the repository:

```
python3 SDK/module.py pack /path/to/MyModule /path/to/MyModule.neronookmodule
```

In NeroNook Settings → Modules → Install Module, choose the resulting file and review the installation. The Modules tab on each Nook renders enabled modules. Change each monitor's visibility in settings. Compact activity is opt-in; the first eligible module is shown, so two modules never compete for the same compact space.

The current `.neronookmodule` format is a single JSON envelope, not a ZIP archive. There is no extraction or remote code fetching. The packer joins `manifest.json` and `main.js`; the app performs authoritative schema and size validation before installation. The folder is a source workspace, not a live-reload plugin. Updates currently require removal/reinstallation and reset module data. Atomic updates and migration/rollback are planned for the creator beta.

## Package and runtime contract

Required manifest fields:

- `schemaVersion: 1`, `hostAPIVersion: 1`, a reverse-domain `id`, `name`, `author`, three-part `version`, `summary`.
- `permissions: []` for local modules, or `["local.mqtt.read"]` with one declared feed. All other permissions are rejected.
- `initialState`: a string-to-string dictionary.
- `settings`: text settings `{id, label, defaultValue}`. They save on Return or focus loss; 200 characters per value.
- `actions`: local actions `{id, label}`. They only transform this module's state. No external side effects or automatic replay.
- `card` and `page`: lists of `{id, kind, text}` components. Kinds: `heading`, `text`, `badge`, `progress`, `button`. A progress component has `valueKey` (0–100). A button has `action` referring to a declared action.
- Optional `activity`: a short text template.

Templates replace `{key}` from module state, then settings. Unavailable values display an em dash. Substitution occurs once, and strings never become HTML or code.

`main.js` defines a synchronous global function:

```js
function reduce(state, action, settings) {
    // action is null on initialization/reload or the declared action ID.
    return { count: String(Number(state.count || '0') + (action === 'increment' ? 1 : 0)) };
}
```

Every invocation creates a fresh JavaScript context in a separate helper process. Global variables do not persist. Return the entire next state with string values. The host validates and atomically persists a successful response; failure retains the previous state. Explicit state is shared across displays. Disabled modules cannot run; disabling/removing cancels in-flight work, and stale responses are ignored.

Limits: 256 KB package, 128 KB script, 32 KB state, 64 state keys, 2 KB per state value, 12 settings, 20 actions, 12 card/40 page components, 20 installed modules, four concurrent invocations. A run has a three-second wall deadline and two CPU seconds. Exceptions, malformed output and helper crashes become module errors. No module-controlled timers or background polling. One host-owned MQTT feed per module is available as described below. Resource containment for hostile packages remains a creator-beta gate; process deadlines do not constitute a comprehensive memory quota.

## Bambu sample

`Modules/Bambu` uses exactly the same public module contract. Advance/pause/error/reset change fixture data only. All cards explicitly say **SIMULATOR · not connected**. There are no credentials, printer connections or print controls. `Modules/BambuMonitor` is the separate live, read-only example. Wider model/firmware compatibility still requires verification.

## Validation and packaging

Run `swift test`, then `bash scripts/package.sh`. Helper integration tests require the packaged app, so run tests again after packaging. The package script embeds and signs the helper with App Sandbox and no network/file entitlements. CLI-only `swift run NeroNook` cannot run modules because it does not bundle the helper. The current signature is ad hoc for local development, not Developer ID/notarization.

For a command-line toolchain whose default SDK is incompatible with SwiftUI, an explicit SDK can be selected using `NERONOOK_SDK_PATH` for packaging and `swift test --sdk /path/to/SDK` for tests. Do not change system toolchain selection automatically.

Apple references: [JavaScriptCore](https://developer.apple.com/documentation/javascriptcore), [App Sandbox](https://developer.apple.com/documentation/security/app-sandbox). A subprocess alone is not a security boundary; the sandbox entitlements and native denial probes are checked separately from JavaScript's missing host APIs.

TypeScript authoring, generated types, typed events/action input schemas, additional transports, publisher signatures, package updates and third-party publishing remain planned SDK work. No source license is granted by this preview guide; select the SDK/examples license before external publication.

## Local MQTT feeds — host 0.7.0 and later

Add `"permissions": ["local.mqtt.read"]` and `"feeds": [{"id":"status","label":"Device status"}]` to the manifest. Define `receive` alongside `reduce`:

```js
function receive(state, event, settings) {
    if (event.feedID !== 'status') return state;
    const report = JSON.parse(event.json);
    return { value: String(report.value ?? 'Unavailable') };
}
```

The user connects the device separately after package installation. That grant binds the exact package fingerprint, feed ID, private IPv4 address, TLS port 8883, certificate identity, trusted PEM anchors, username and exact topic. A changed package needs a new grant. Only the broker reads the scoped Keychain access code. Modules receive bounded JSON data; no password or connection object crosses into JavaScript. The setup screen can explicitly import an existing local Bambu Studio access code and public certificates; nothing is imported automatically on install.

The broker uses MQTT 3.1.1 CONNECT/SUBSCRIBE/keepalive/acknowledgements. There is no application PUBLISH path or command API. Topics cannot contain wildcards. TLS verifies the configured trust chain and identity. For device certificates that use serial-number common names, the connection's explicit serial option validates the X.509 chain/expiry and exact serial CN; ordinary profiles use the standard SSL hostname policy. Trust is local to this connection and never added to the system trust store.

JSON object patches merge recursively into the latest connection snapshot (arrays replace, null removes; depth 12). Frames are limited to 128 KB, incoming JSON and merged snapshots to 64 KB. Delivery is coalesced to at most once every two seconds with the latest pending snapshot retained. Each connection starts a fresh cache. Modules must tolerate partial/missing data after reconnect. This feed is for latest status, not guaranteed event delivery: short intermediate transitions can be coalesced or missed during disconnects.

Disable, removal, sleep and disconnect stop the subscription and cancel pending module work. The same connection feeds every selected monitor. Auto-reconnect uses bounded backoff; rejected sign-in/subscription requires manual attention. macOS local-network permission waits keep the connection available to resume after approval. Credential reads are asynchronous, deduplicated and discarded after disable, removal or shutdown. Disconnect revokes the Keychain entry. Saved module state may contain job names and remains until the module is removed; connection health and last-report time are rendered separately by the host.

Bambu Monitor displays available report fields and records only observed same-job completion/error transitions. An initially completed job is not announced as newly completed. These are in-app event descriptions; OS notifications, durable event delivery, camera, multiple printer instances, controls, cloud access and the model/firmware matrix remain later work.

## Development signing and local network permission

Use `NERONOOK_SIGNING_IDENTITY` to select your Apple-issued code-signing identity when packaging; otherwise the script uses an ad hoc signature. macOS may block or fail to track local-network permission reliably for ad hoc apps. Allow NeroNook in System Settings → Privacy & Security → Local Network, then reconnect. Development signing is not notarization or permission to publish. [Apple local-network guidance](https://developer.apple.com/documentation/technotes/tn3179-understanding-local-network-privacy)

Protocol references: [MQTT 3.1.1](https://docs.oasis-open.org/mqtt/mqtt/v3.1.1/os/mqtt-v3.1.1-os.html) and [Bambu Studio's report parser](https://github.com/bambulab/BambuStudio/blob/master/src/slic3r/GUI/DeviceManager.cpp). No printer certificates or private reports are bundled with the SDK.


## Native printer tools (host 0.8.0)

A user may enable **Native printer tools** on a Bambu connection in Settings → Modules. The host recognizes the explicit serial-certificate identity, `bblp` account and exact `device/<serial>/report` topic; no module ID is special-cased. Module JavaScript still receives only the read-only status feed. It cannot publish, call printer controls, open a camera socket, read the access code, or choose arbitrary files.

The host adds its own camera and controls below the module card. Camera uses local TLS/RTSP with H.264 decoding; current-plate metadata uses the printer's local file service and a fixed slice-info path. These features share the approved connection and Keychain credential. Full certificate-chain validation, expiration and exact serial identity remain enforced, including when the camera/file service omits the intermediate already verified through MQTT.

Every physical action requires native review, binds to the same saved connection and active job, expires after 30 seconds, and requires a report less than 10 seconds old. The wire layer rechecks the job/state. Part skipping additionally requires firmware capability, labeled slice metadata, exact current object IDs, and at least one remaining object. Commands are never automatically retried; broker delivery, device acknowledgement and observed printer state are reported separately. No generalized write API is exposed to packages.

Camera is opt-in when opened, shared between displays through one host window per connection, and stops on close, module disable, disconnection or sleep. Camera support is model/firmware dependent; a cloud stream in Bambu Studio does not prove local RTSP is enabled. BambuBoy's local stream was disabled during 0.8.0 acceptance. The native stream pipeline passed a loopback fixture, not a live camera acceptance.

The portable acceptance harness in `scripts/printer-acceptance.swift` runs against `NookModuleKit` and exercises state freshness, review expiry, job identity, object selection, XML limits, RTSP framing and H.264 RTP recovery. Build the library, then compile the harness using the same SDK; it does not connect to any printer.

For full native loopback verification, run `bash scripts/test-printer-native.sh`. It generates its own temporary CA and test video, listens only on loopback ports 13322/8883, and sends all physical-action payloads exclusively to the local fixture broker. No actual printer is contacted.


### Camera sources in host 0.8.1

The camera window supports direct authenticated RTSPS or Bambu Studio's existing Go Live output. If the device explicitly reports direct streaming disabled, it selects Studio and waits for the user to enable Go Live. The receiver listens only on `127.0.0.1:1234`, with no port reuse; its video is explicitly the printer selected in Studio, not an authenticated identity claim about the module's printer. Users can switch sources in the native window.

No Studio authentication URL, cloud token or private library is accessed. Studio remains responsible for fetching its video and forwarding the user-enabled local stream; NeroNook handles RTP/H.264 decoding itself. The public `ffmpeg.sdp` can provide initial codec parameters. Module JavaScript still has no video/credential/network access. `test-printer-native.sh` now also verifies Studio-style RTP playback, stalled-video detection and receiver stop/reopen using synthetic frames on loopback port 13324, without reading user SDP or contacting a printer.

See the [module presentation contract](MODULE-PRESENTATION.md) for viewport size, status, selector, artwork and lifecycle requirements.
