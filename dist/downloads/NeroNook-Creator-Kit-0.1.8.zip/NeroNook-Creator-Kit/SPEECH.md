# Optional local speech · SDK actions-v1

Added 13 October 2026. Speech is supplied by an independent plugin. The host
uses its existing generic action routing; it contains no synthesizer, voice ID,
provider allowlist, microphone path or speech assets. The current installed
host baseline is 0.26.3, with no new wire feature.

## Contract

`PluginSpeechContract.speak` registers `speak_text`, with exactly one required
`text: string` input and one `spoken: boolean` output. An invocation accepts up
to 2,048 UTF-8 bytes, nonblank text, and no control characters except line breaks
and tabs. It is cancellable, with a 180-second action timeout. Preparation and
playback emit running updates. Success with `spoken: true` means the selected
provider finished playback; it says nothing about execution of any described
operation. Failure and cancellation remain distinct outcomes.

The action's readOnly classification means ephemeral local output, with no
persisted content mutation, credential use, microphone recording or remote
service delivery. It is audible and must remain an intentional user operation.
This contract does not authorize autonomous announcements. Installed Agent
0.3.2 excludes speech entries from the model's tool catalog and exposes Read
aloud only on an existing completed assistant message. Fuego Agent 0.1.1 reads
its current status only when the user presses Read status.

## Consumer

`PluginSpeechClient` discovers only granted actions whose entire declaration
matches the contract. The user chooses a provider. Keep this optional: missing
Voice or a revoked grant disables reading without disabling the module.

Set `send` to the module's generic bus sender, pass completed catalogs to
`catalog`, and pass bus responses to `receive`. Call `read(text)` from a user
button and `stop()` from Stop, navigation and shutdown. Longer text is split
at character boundaries into sequential invocations of at most 2 KiB; the total
limit is 32 KiB and 32 segments. Only successful completion of the active
request advances the queue. A catalog refresh, including an identical catalog,
retires playback. Reconnection never resumes it automatically. Retired request
IDs cannot advance the queue. Providers serialize playback and must implement
cancellation and late-callback suppression themselves.

A cross-plugin routing grant is still required. This does not grant an agent
microphone or meeting-library access. Review the provider's declared local
output behavior and voice settings independently. See [actions](ACTIONS.md).

## Current implementation and verification

Voice 0.11.2 owns Apple speech and voice/delivery preferences, including Apple
American English Voice 2 through its bounded Ember-compatible helper. Agent
0.3.2 and Fuego Agent 0.1.1 contain only the shared consumer. Their SDK snapshots
record the exact copied source. Three host-side client tests cover schema and
UTF-8 limits, sequential progression, Stop, stale callbacks and catalog changes.
Native Agent and Fuego playback completion and immediate Stop passed against the
installed Voice provider. Agent uses a completed real account-backed reply with
Nook context off; no meeting-text access was granted. Public creator/distribution qualification remains open.
